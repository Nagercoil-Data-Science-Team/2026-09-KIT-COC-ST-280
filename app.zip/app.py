"""
====================================================================================================
Real-Time Monitoring UI for FPGA-Based Parallel Signal Processing
====================================================================================================
Research Project:
"The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput in Real-Time 
Embedded Communication Systems"

Technologies: Streamlit, Plotly, NumPy, Pandas, Scipy
Target Architecture: AMD/Xilinx Zynq UltraScale+ XCZU9EG
Models: S-FPGA (Sequential), P-FPGA (Parallel), PP-FPGA (Parallel Pipelined)
====================================================================================================
"""

import sys
import time
import math
from pathlib import Path
import numpy as np
import pandas as pd
import scipy.signal as signal
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

# ==================================================================================================
# PAGE CONFIGURATION & STYLING
# ==================================================================================================
st.set_page_config(
    page_title="FPGA Signal Processing Real-Time Telemetry",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom High-Tech Dark / Clean CSS Styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;600&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }
    
    .metric-card {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.7) 0%, rgba(15, 23, 42, 0.8) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 16px 20px;
        box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.3);
        margin-bottom: 12px;
    }
    
    .metric-title {
        color: #94a3b8;
        font-size: 0.80rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 6px;
    }
    
    .metric-value {
        color: #f8fafc;
        font-size: 1.60rem;
        font-weight: 700;
        font-family: 'JetBrains Mono', monospace;
    }
    
    .metric-delta {
        font-size: 0.80rem;
        font-weight: 500;
        margin-top: 4px;
    }
    
    .status-pill {
        display: inline-flex;
        align-items: center;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    
    .status-active {
        background-color: rgba(34, 197, 94, 0.15);
        color: #4ade80;
        border: 1px solid rgba(34, 197, 94, 0.3);
    }
    
    .status-info {
        background-color: rgba(56, 189, 248, 0.15);
        color: #38bdf8;
        border: 1px solid rgba(56, 189, 248, 0.3);
    }
    
    .status-warning {
        background-color: rgba(245, 158, 11, 0.15);
        color: #fbbf24;
        border: 1px solid rgba(245, 158, 11, 0.3);
    }
</style>
""", unsafe_allow_html=True)

# ==================================================================================================
# DATA LOADING & CACHING
# ==================================================================================================
BASE_DIR = Path(__file__).resolve().parent / "FPGA_Signal_Processing_Results"

@st.cache_data
def load_project_data():
    """Loads all pre-generated datasets and tables if available."""
    data = {}
    data_dir = BASE_DIR / "data"
    tables_dir = BASE_DIR / "tables"
    summary_dir = BASE_DIR / "summary"

    if data_dir.exists():
        if (data_dir / "generated_signal_samples.csv").exists():
            data['raw_samples'] = pd.read_csv(data_dir / "generated_signal_samples.csv")
        if (data_dir / "preprocessed_signal_samples.csv").exists():
            data['preprocessed_samples'] = pd.read_csv(data_dir / "preprocessed_signal_samples.csv")
        if (data_dir / "signal_windows.csv").exists():
            data['windows'] = pd.read_csv(data_dir / "signal_windows.csv")
        if (data_dir / "spectral_features.csv").exists():
            data['spectral'] = pd.read_csv(data_dir / "spectral_features.csv")

    if tables_dir.exists():
        for t_file in tables_dir.glob("table_*.csv"):
            data[t_file.stem] = pd.read_csv(t_file)

    if summary_dir.exists() and (summary_dir / "experimental_summary.csv").exists():
        data['summary'] = pd.read_csv(summary_dir / "experimental_summary.csv")

    return data

DATA_STORE = load_project_data()

# ==================================================================================================
# HARDWARE CONSTANTS & SIMULATION ENGINE
# ==================================================================================================
DEVICE_SPECS = {
    'AMD/Xilinx Zynq UltraScale+ XCZU9EG': {
        'LUT_total': 274080, 'FF_total': 548160, 'BRAM_total': 912, 'DSP_total': 2520, 'V_core': 0.85
    },
    'AMD/Xilinx Kintex UltraScale+ XCKU15P': {
        'LUT_total': 522720, 'FF_total': 1045440, 'BRAM_total': 1968, 'DSP_total': 1968, 'V_core': 0.85
    },
    'AMD/Xilinx Artix UltraScale+ AU25P': {
        'LUT_total': 138240, 'FF_total': 276480, 'BRAM_total': 600, 'DSP_total': 1200, 'V_core': 0.85
    }
}

def calculate_hardware_metrics(arch: str, win_size: int, n_taps: int, p_factor: int, 
                               f_clk_mhz: float, device_name: str):
    """
    Computes real-time analytical simulation metrics for the given architecture.
    """
    dev = DEVICE_SPECS.get(device_name, DEVICE_SPECS['AMD/Xilinx Zynq UltraScale+ XCZU9EG'])
    f_clk = f_clk_mhz * 1e6
    win_bits = win_size * 32  # 16-bit I + 16-bit Q

    # DMA transfer over AXI4-Stream 64-bit @ 200 MHz
    dma_bytes = win_size * 4
    dma_cycles = math.ceil(dma_bytes / 8)
    t_dma_s = 1.5e-6 + (dma_cycles / 200e6)  # setup + burst

    if arch == "S-FPGA":
        # Sequential single MAC
        fir_cycles = win_size * n_taps
        fft_butterflies = (win_size // 2) * int(math.log2(win_size))
        fft_cycles = fft_butterflies * 4
        comp_cycles = fir_cycles + fft_cycles
        t_comp_s = comp_cycles / f_clk
        t_total_s = (2 * t_dma_s) + t_comp_s
        th_mbps = (win_bits / t_total_s) / 1e6
        
        lut_used = int(14250 * (n_taps / 64.0))
        ff_used = 16400
        bram_used = 18
        dsp_used = 6
        p_static = 1.10
        p_dyn = 0.55 * (f_clk_mhz / 150.0)

    elif arch == "P-FPGA":
        # Spatial parallel P processing lanes
        fir_cycles = math.ceil((win_size * n_taps) / p_factor) + 16
        fft_butterflies = (win_size // 2) * int(math.log2(win_size))
        fft_cycles = math.ceil((fft_butterflies * 4) / p_factor) + 16
        comp_cycles = fir_cycles + fft_cycles
        t_comp_s = comp_cycles / f_clk
        t_total_s = (2 * t_dma_s) + t_comp_s
        th_mbps = (win_bits / t_total_s) / 1e6
        
        lut_used = int(48600 * (p_factor / 8.0))
        ff_used = int(52300 * (p_factor / 8.0))
        bram_used = int(46 * (p_factor / 8.0))
        dsp_used = int(9 * p_factor)
        p_static = 1.15
        p_dyn = 1.95 * (p_factor / 8.0) * (f_clk_mhz / 200.0)

    else:  # PP-FPGA
        # Pipelined Streaming SDF
        fir_cycles = n_taps + math.ceil(win_size / p_factor)
        fft_cycles = math.ceil(win_size / p_factor) + int(math.log2(win_size)) * 4
        comp_cycles = fir_cycles + fft_cycles
        t_comp_s = comp_cycles / f_clk
        # In continuous streaming, steady-state interval is bounded by max pipeline stage
        stage_interval_s = max(t_dma_s, t_comp_s / 2.0)
        t_total_s = (2 * t_dma_s) + t_comp_s  # End-to-end latency for one packet
        th_mbps = (win_bits / stage_interval_s) / 1e6

        lut_used = int(92400 * (p_factor / 8.0))
        ff_used = int(138500 * (p_factor / 8.0))
        bram_used = int(98 * (win_size / 512.0))
        dsp_used = int(32 * p_factor)
        p_static = 1.22
        p_dyn = 3.63 * (p_factor / 8.0) * (f_clk_mhz / 250.0)

    p_total = p_static + p_dyn
    energy_uj = p_total * t_total_s * 1e6
    energy_nj_bit = (energy_uj * 1e3) / win_bits

    return {
        'arch': arch,
        'f_clk_mhz': f_clk_mhz,
        't_dma_ms': t_dma_s * 1000.0,
        't_comp_ms': t_comp_s * 1000.0,
        't_total_ms': t_total_s * 1000.0,
        'throughput_mbps': th_mbps,
        'lut_used': lut_used,
        'lut_pct': (lut_used / dev['LUT_total']) * 100.0,
        'ff_used': ff_used,
        'ff_pct': (ff_used / dev['FF_total']) * 100.0,
        'bram_used': bram_used,
        'bram_pct': (bram_used / dev['BRAM_total']) * 100.0,
        'dsp_used': dsp_used,
        'dsp_pct': (dsp_used / dev['DSP_total']) * 100.0,
        'power_static_w': p_static,
        'power_dynamic_w': p_dyn,
        'power_total_w': p_total,
        'energy_window_uj': energy_uj,
        'energy_efficiency_nj_bit': energy_nj_bit
    }

# ==================================================================================================
# SIDEBAR CONTROLS & NAVIGATION
# ==================================================================================================
st.sidebar.markdown("## ⚡ FPGA Telemetry Center")
st.sidebar.caption("Parallel Signal Processing & Hardware Latency Evaluation")

mode = st.sidebar.radio(
    "Navigation Mode",
    [
        "📡 Real-Time Streaming Monitor",
        "⚖️ Architectural Comparison (S vs P vs PP)",
        "🔬 FPGA Hardware Architecture Sandbox",
        "📊 IEEE Datasets & Tables Explorer",
        "🖼️ Publication Figures Gallery"
    ]
)

st.sidebar.divider()
st.sidebar.markdown("### ⚙️ Telemetry Configuration")

selected_model = st.sidebar.selectbox(
    "Active FPGA Model",
    ["PP-FPGA (Parallel Pipelined)", "P-FPGA (Parallel)", "S-FPGA (Sequential)"],
    index=0
)
arch_key = selected_model.split()[0]

target_device = st.sidebar.selectbox(
    "Target FPGA Platform",
    list(DEVICE_SPECS.keys()),
    index=0
)

snr_options = ["SIG_03_SNR_10dB", "SIG_01_SNR_0dB", "SIG_02_SNR_5dB", "SIG_04_SNR_15dB", "SIG_05_SNR_20dB"]
selected_signal = st.sidebar.selectbox(
    "Active Signal Stream (SNR)",
    snr_options,
    index=0
)

window_length = st.sidebar.select_slider(
    "Window Size (N Samples)",
    options=[128, 256, 512, 1024, 2048],
    value=512
)

# ==================================================================================================
# SYSTEM HEADER & LIVE STATUS BAR
# ==================================================================================================
col_h1, col_h2 = st.columns([3, 1])

with col_h1:
    st.title("FPGA Parallel Signal Processing Telemetry Monitor")
    st.markdown("**Research:** *The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput in Real-Time Embedded Communication Systems*")

with col_h2:
    st.markdown("""
        <div style="text-align: right; padding-top: 10px;">
            <span class="status-pill status-active">● STREAMING ACTIVE</span><br>
            <span class="status-pill status-info" style="margin-top: 5px;">AXI4-Stream DMA: LOCKED</span><br>
            <span class="status-pill status-warning" style="margin-top: 5px;">CLOCK: 250 MHz</span>
        </div>
    """, unsafe_allow_html=True)

st.divider()

# ==================================================================================================
# TAB 1: REAL-TIME STREAMING MONITOR
# ==================================================================================================
if mode == "📡 Real-Time Streaming Monitor":
    st.subheader("📡 Real-Time Streaming Dataflow & Telemetry Gauges")

    # Streaming Control Bar
    ctrl_col1, ctrl_col2, ctrl_col3, ctrl_col4 = st.columns([1.5, 1.5, 3, 2])
    
    if 'current_window_idx' not in st.session_state:
        st.session_state.current_window_idx = 0
    if 'is_playing' not in st.session_state:
        st.session_state.is_playing = False

    with ctrl_col1:
        if st.button("▶️ Start Live Stream", use_container_width=True):
            st.session_state.is_playing = True
    with ctrl_col2:
        if st.button("⏸️ Pause Stream", use_container_width=True):
            st.session_state.is_playing = False
    with ctrl_col3:
        win_slider = st.slider("Scrub Window Position", 0, 39, st.session_state.current_window_idx, 1)
        st.session_state.current_window_idx = win_slider
    with ctrl_col4:
        if st.button("⏮️ Reset to Window 0", use_container_width=True):
            st.session_state.current_window_idx = 0
            st.session_state.is_playing = False

    # Current Window Index
    cur_win = st.session_state.current_window_idx
    
    # Calculate Live Model Metrics
    f_clk_map = {'S-FPGA': 150.0, 'P-FPGA': 200.0, 'PP-FPGA': 250.0}
    p_fac_map = {'S-FPGA': 1, 'P-FPGA': 8, 'PP-FPGA': 8}
    cur_metrics = calculate_hardware_metrics(
        arch=arch_key,
        win_size=window_length,
        n_taps=64,
        p_factor=p_fac_map[arch_key],
        f_clk_mhz=f_clk_map[arch_key],
        device_name=target_device
    )

    # Reference S-FPGA for Speedup Delta
    s_metrics = calculate_hardware_metrics('S-FPGA', window_length, 64, 1, 150.0, target_device)
    speedup = s_metrics['t_total_ms'] / cur_metrics['t_total_ms']

    # Metric Dashboard Ribbon
    m_col1, m_col2, m_col3, m_col4, m_col5, m_col6 = st.columns(6)
    with m_col1:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Total Latency</div>
                <div class="metric-value">{cur_metrics['t_total_ms']:.4f} <span style="font-size: 0.9rem; color: #94a3b8;">ms</span></div>
                <div class="metric-delta" style="color: #4ade80;">Comp: {cur_metrics['t_comp_ms']:.4f} ms</div>
            </div>
        """, unsafe_allow_html=True)
    with m_col2:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Throughput</div>
                <div class="metric-value">{cur_metrics['throughput_mbps']:.1f} <span style="font-size: 0.9rem; color: #94a3b8;">Mbps</span></div>
                <div class="metric-delta" style="color: #38bdf8;">Rate: {cur_metrics['throughput_mbps']/1000.0:.2f} Gbps</div>
            </div>
        """, unsafe_allow_html=True)
    with m_col3:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Latency Speedup</div>
                <div class="metric-value">{speedup:.2f}x</div>
                <div class="metric-delta" style="color: #fbbf24;">vs Sequential Baseline</div>
            </div>
        """, unsafe_allow_html=True)
    with m_col4:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Power Draw</div>
                <div class="metric-value">{cur_metrics['power_total_w']:.2f} <span style="font-size: 0.9rem; color: #94a3b8;">W</span></div>
                <div class="metric-delta" style="color: #94a3b8;">Dynamic: {cur_metrics['power_dynamic_w']:.2f} W</div>
            </div>
        """, unsafe_allow_html=True)
    with m_col5:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">Energy / Window</div>
                <div class="metric-value">{cur_metrics['energy_window_uj']:.2f} <span style="font-size: 0.9rem; color: #94a3b8;">µJ</span></div>
                <div class="metric-delta" style="color: #4ade80;">{cur_metrics['energy_efficiency_nj_bit']:.2f} nJ / bit</div>
            </div>
        """, unsafe_allow_html=True)
    with m_col6:
        st.markdown(f"""
            <div class="metric-card">
                <div class="metric-title">DSP Utilization</div>
                <div class="metric-value">{cur_metrics['dsp_pct']:.1f}%</div>
                <div class="metric-delta" style="color: #38bdf8;">LUTs: {cur_metrics['lut_pct']:.1f}%</div>
            </div>
        """, unsafe_allow_html=True)

    # Signal Slice Extraction
    df_raw = DATA_STORE.get('raw_samples', None)
    df_pre = DATA_STORE.get('preprocessed_samples', None)

    if df_raw is not None and df_pre is not None:
        sub_raw = df_raw[df_raw['signal_id'] == selected_signal]
        sub_pre = df_pre[df_pre['signal_id'] == selected_signal]

        # Extract current window slice
        start_idx = (cur_win % 8) * window_length
        end_idx = start_idx + window_length

        if end_idx <= len(sub_raw):
            win_raw = sub_raw.iloc[start_idx:end_idx]
            win_pre = sub_pre.iloc[start_idx:end_idx]
        else:
            win_raw = sub_raw.iloc[:window_length]
            win_pre = sub_pre.iloc[:window_length]
    else:
        # Generate on the fly if files aren't pre-loaded
        t_live = np.arange(window_length) / 20e6
        i_clean = np.cos(2 * np.pi * 2.5e6 * t_live)
        q_clean = np.sin(2 * np.pi * 2.5e6 * t_live)
        win_raw = pd.DataFrame({'time_sec': t_live, 'I': i_clean, 'Q': q_clean, 'amplitude': 1.0})
        win_pre = pd.DataFrame({'time_sec': t_live, 'I_norm': i_clean, 'Q_norm': q_clean, 'amplitude_norm': 1.0})

    # Visualizations: 2 Rows x 2 Columns
    row1_col1, row1_col2 = st.columns([2, 1])

    with row1_col1:
        st.markdown("#### 📺 Live Time-Domain Oscilloscope (I & Q Streams)")
        fig_scope = go.Figure()
        t_us = win_pre['time_sec'].values * 1e6
        fig_scope.add_trace(go.Scatter(x=t_us, y=win_pre['I_norm'], mode='lines', name='In-phase (I)', line=dict(color='#38bdf8', width=1.5)))
        fig_scope.add_trace(go.Scatter(x=t_us, y=win_pre['Q_norm'], mode='lines', name='Quadrature (Q)', line=dict(color='#fb923c', width=1.5, dash='dash')))
        fig_scope.add_trace(go.Scatter(x=t_us, y=win_pre['amplitude_norm'], mode='lines', name='Envelope', line=dict(color='#4ade80', width=1.0)))
        fig_scope.update_layout(
            height=320,
            margin=dict(l=40, r=20, t=30, b=40),
            xaxis_title="Time (µs)",
            yaxis_title="Normalized Amplitude",
            template="plotly_dark",
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        st.plotly_chart(fig_scope, use_container_width=True)

    with row1_col2:
        st.markdown("#### 🎯 I/Q Constellation Diagram")
        fig_const = go.Figure()
        fig_const.add_trace(go.Scatter(
            x=win_raw['I'], y=win_raw['Q'], mode='markers',
            name='Raw IQ Cloud',
            marker=dict(size=4, color='#ef4444', opacity=0.35)
        ))
        fig_const.add_trace(go.Scatter(
            x=win_pre['I_norm'], y=win_pre['Q_norm'], mode='markers',
            name='Preprocessed IQ',
            marker=dict(size=4.5, color='#38bdf8', opacity=0.75)
        ))
        fig_const.update_layout(
            height=320,
            margin=dict(l=40, r=20, t=30, b=40),
            xaxis_title="In-Phase (I)",
            yaxis_title="Quadrature (Q)",
            template="plotly_dark",
            xaxis=dict(scaleanchor="y", scaleratio=1),
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        st.plotly_chart(fig_const, use_container_width=True)

    row2_col1, row2_col2 = st.columns([2, 1])

    with row2_col1:
        st.markdown("#### 🌈 Complex FFT Spectrum Analyzer")
        # Compute live FFT
        complex_chunk = (win_pre['I_norm'].values + 1j * win_pre['Q_norm'].values) * np.hanning(len(win_pre))
        fft_vals = np.abs(np.fft.fft(complex_chunk, n=window_length))
        freqs_mhz = (np.fft.fftfreq(window_length, d=1.0 / 20.0e6) / 1e6)
        pos_mask = freqs_mhz >= 0
        f_axis = freqs_mhz[pos_mask]
        mag_db = 20 * np.log10(np.maximum(fft_vals[pos_mask], 1e-6))
        mag_db -= np.max(mag_db)

        peak_idx = np.argmax(mag_db)
        carrier_peak_freq = f_axis[peak_idx]

        fig_fft = go.Figure()
        fig_fft.add_trace(go.Scatter(x=f_axis, y=mag_db, mode='lines', name='Magnitude Spectrum (dB)', line=dict(color='#a855f7', width=1.8)))
        fig_fft.add_vline(x=carrier_peak_freq, line_width=1.5, line_dash="dash", line_color="#ef4444", annotation_text=f"Carrier: {carrier_peak_freq:.2f} MHz")
        fig_fft.add_hline(y=-3.0, line_width=1.2, line_dash="dot", line_color="#4ade80", annotation_text="-3 dB Bandwidth")
        fig_fft.update_layout(
            height=320,
            margin=dict(l=40, r=20, t=30, b=40),
            xaxis_title="Frequency (MHz)",
            yaxis_title="Normalized Magnitude (dB)",
            template="plotly_dark",
            yaxis=dict(range=[-50, 5])
        )
        st.plotly_chart(fig_fft, use_container_width=True)

    with row2_col2:
        st.markdown("#### ⏱️ Latency Stage Breakdown")
        stages = ['H2F DMA', 'FIR Filter', 'FFT Engine', 'F2H DMA']
        if arch_key == 'S-FPGA':
            delays = [cur_metrics['t_dma_ms'], cur_metrics['t_comp_ms'] * 0.78, cur_metrics['t_comp_ms'] * 0.22, cur_metrics['t_dma_ms']]
        elif arch_key == 'P-FPGA':
            delays = [cur_metrics['t_dma_ms'], cur_metrics['t_comp_ms'] * 0.77, cur_metrics['t_comp_ms'] * 0.23, cur_metrics['t_dma_ms']]
        else:
            delays = [cur_metrics['t_dma_ms'], cur_metrics['t_comp_ms'] * 0.56, cur_metrics['t_comp_ms'] * 0.44, cur_metrics['t_dma_ms']]

        fig_stages = go.Figure(go.Bar(
            x=stages, y=delays,
            marker_color=['#3b82f6', '#10b981', '#f59e0b', '#6366f1'],
            text=[f"{d:.4f} ms" for d in delays], textposition='auto'
        ))
        fig_stages.update_layout(
            height=320,
            margin=dict(l=40, r=20, t=30, b=40),
            xaxis_title="Processing Stage",
            yaxis_title="Stage Latency (ms)",
            template="plotly_dark"
        )
        st.plotly_chart(fig_stages, use_container_width=True)

    # Auto-play loop trigger if streaming active
    if st.session_state.is_playing:
        time.sleep(0.3)
        st.session_state.current_window_idx = (st.session_state.current_window_idx + 1) % 40
        st.rerun()

# ==================================================================================================
# TAB 2: ARCHITECTURAL COMPARISON (S vs P vs PP)
# ==================================================================================================
elif mode == "⚖️ Architectural Comparison (S vs P vs PP)":
    st.subheader("⚖️ Architectural Benchmark & Multi-Model Comparative Evaluation")
    st.caption("Comprehensive comparison between Sequential (S-FPGA), Parallel (P-FPGA), and Parallel Pipelined (PP-FPGA)")

    # Compute metrics for all 3 models
    m_s = calculate_hardware_metrics('S-FPGA', window_length, 64, 1, 150.0, target_device)
    m_p = calculate_hardware_metrics('P-FPGA', window_length, 64, 8, 200.0, target_device)
    m_pp = calculate_hardware_metrics('PP-FPGA', window_length, 64, 8, 250.0, target_device)

    # Top Comparative Cards
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(f"""
            <div class="metric-card" style="border-left: 4px solid #1f77b4;">
                <div class="metric-title">Sequential FPGA (S-FPGA)</div>
                <div class="metric-value">{m_s['t_total_ms']:.4f} ms</div>
                <div class="metric-delta" style="color: #94a3b8;">Throughput: {m_s['throughput_mbps']:.1f} Mbps | Speedup: 1.00x</div>
                <div class="metric-delta" style="color: #38bdf8;">Power: {m_s['power_total_w']:.2f} W | DSP: {m_s['dsp_pct']:.2f}%</div>
            </div>
        """, unsafe_allow_html=True)
    with c2:
        st.markdown(f"""
            <div class="metric-card" style="border-left: 4px solid #ff7f0e;">
                <div class="metric-title">Parallel FPGA (P-FPGA)</div>
                <div class="metric-value">{m_p['t_total_ms']:.4f} ms</div>
                <div class="metric-delta" style="color: #4ade80;">Throughput: {m_p['throughput_mbps']:.1f} Mbps | Speedup: {m_s['t_total_ms']/m_p['t_total_ms']:.2f}x</div>
                <div class="metric-delta" style="color: #38bdf8;">Power: {m_p['power_total_w']:.2f} W | DSP: {m_p['dsp_pct']:.2f}%</div>
            </div>
        """, unsafe_allow_html=True)
    with c3:
        st.markdown(f"""
            <div class="metric-card" style="border-left: 4px solid #2ca02c;">
                <div class="metric-title">Parallel Pipelined (PP-FPGA)</div>
                <div class="metric-value">{m_pp['t_total_ms']:.4f} ms</div>
                <div class="metric-delta" style="color: #4ade80;">Throughput: {m_pp['throughput_mbps']:.1f} Mbps | Speedup: {m_s['t_total_ms']/m_pp['t_total_ms']:.2f}x</div>
                <div class="metric-delta" style="color: #38bdf8;">Power: {m_pp['power_total_w']:.2f} W | DSP: {m_pp['dsp_pct']:.2f}%</div>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("### 📊 Interactive Comparative Plots")
    p_col1, p_col2 = st.columns(2)

    with p_col1:
        # Latency Comparison Bar Chart
        fig_lat = go.Figure()
        archs = ['Sequential (S-FPGA)', 'Parallel (P-FPGA)', 'Parallel Pipelined (PP-FPGA)']
        totals = [m_s['t_total_ms'], m_p['t_total_ms'], m_pp['t_total_ms']]
        comps = [m_s['t_comp_ms'], m_p['t_comp_ms'], m_pp['t_comp_ms']]
        dmas = [2 * m_s['t_dma_ms'], 2 * m_p['t_dma_ms'], 2 * m_pp['t_dma_ms']]

        fig_lat.add_trace(go.Bar(name='Computation Latency', x=archs, y=comps, marker_color='#3b82f6'))
        fig_lat.add_trace(go.Bar(name='DMA Transfer Latency (H2F+F2H)', x=archs, y=dmas, marker_color='#f59e0b'))
        fig_lat.update_layout(
            barmode='stack', height=360,
            title="Total Latency Breakdown (ms)",
            xaxis_title="FPGA Architectural Model",
            yaxis_title="Total Latency per Window (ms)",
            template="plotly_dark",
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        st.plotly_chart(fig_lat, use_container_width=True)

    with p_col2:
        # Throughput & Speedup Dual Axis Chart
        fig_th = make_subplots(specs=[[{"secondary_y": True}]])
        ths = [m_s['throughput_mbps'], m_p['throughput_mbps'], m_pp['throughput_mbps']]
        spds = [1.0, m_s['t_total_ms']/m_p['t_total_ms'], m_s['t_total_ms']/m_pp['t_total_ms']]

        fig_th.add_trace(go.Bar(name='Throughput (Mbps)', x=archs, y=ths, marker_color='#10b981'), secondary_y=False)
        fig_th.add_trace(go.Scatter(name='Speedup vs S-FPGA', x=archs, y=spds, mode='lines+markers', line=dict(color='#ef4444', width=3), marker=dict(size=10)), secondary_y=True)

        fig_th.update_layout(
            height=360,
            title="Throughput (Mbps) and Overall Speedup Factor",
            xaxis_title="FPGA Architectural Model",
            template="plotly_dark",
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        fig_th.update_yaxes(title_text="Throughput (Mbps)", secondary_y=False)
        fig_th.update_yaxes(title_text="Speedup Factor (x)", secondary_y=True)
        st.plotly_chart(fig_th, use_container_width=True)

    p_col3, p_col4 = st.columns(2)

    with p_col3:
        # Hardware Resources Radar Chart
        categories = ['LUT (%)', 'Flip-Flop (%)', 'BRAM (%)', 'DSP (%)']
        fig_radar = go.Figure()

        fig_radar.add_trace(go.Scatterpolar(
            r=[m_s['lut_pct'], m_s['ff_pct'], m_s['bram_pct'], m_s['dsp_pct']],
            theta=categories, fill='toself', name='S-FPGA', line=dict(color='#1f77b4')
        ))
        fig_radar.add_trace(go.Scatterpolar(
            r=[m_p['lut_pct'], m_p['ff_pct'], m_p['bram_pct'], m_p['dsp_pct']],
            theta=categories, fill='toself', name='P-FPGA', line=dict(color='#ff7f0e')
        ))
        fig_radar.add_trace(go.Scatterpolar(
            r=[m_pp['lut_pct'], m_pp['ff_pct'], m_pp['bram_pct'], m_pp['dsp_pct']],
            theta=categories, fill='toself', name='PP-FPGA', line=dict(color='#2ca02c')
        ))

        fig_radar.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 40])),
            height=360,
            title="Hardware Resource Footprint Radar (% of Device)",
            template="plotly_dark",
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        st.plotly_chart(fig_radar, use_container_width=True)

    with p_col4:
        # Power & Energy Efficiency Comparison
        fig_pwr = go.Figure()
        fig_pwr.add_trace(go.Bar(name='Static Leakage Power (W)', x=archs, y=[m_s['power_static_w'], m_p['power_static_w'], m_pp['power_static_w']], marker_color='#64748b'))
        fig_pwr.add_trace(go.Bar(name='Dynamic Logic Power (W)', x=archs, y=[m_s['power_dynamic_w'], m_p['power_dynamic_w'], m_pp['power_dynamic_w']], marker_color='#ef4444'))

        fig_pwr.update_layout(
            barmode='stack', height=360,
            title="Power Dissipation Breakdown (Static vs Dynamic)",
            xaxis_title="FPGA Architectural Model",
            yaxis_title="Power Consumption (W)",
            template="plotly_dark",
            legend=dict(orientation="h", y=1.1, x=0.5, xanchor="center")
        )
        st.plotly_chart(fig_pwr, use_container_width=True)

# ==================================================================================================
# TAB 3: FPGA HARDWARE ARCHITECTURE SANDBOX
# ==================================================================================================
elif mode == "🔬 FPGA Hardware Architecture Sandbox":
    st.subheader("🔬 Interactive FPGA Hardware Architecture Simulation Sandbox")
    st.caption("Experiment with arbitrary architectural knobs, custom clock frequencies, filter tap lengths, and target FPGA devices")

    sb_c1, sb_c2, sb_c3, sb_c4 = st.columns(4)
    with sb_c1:
        custom_arch = st.selectbox("Architectural Class", ["PP-FPGA", "P-FPGA", "S-FPGA"])
    with sb_c2:
        custom_p = st.select_slider("Parallelism Factor (P)", options=[1, 2, 4, 8, 16, 32], value=8 if custom_arch != "S-FPGA" else 1)
    with sb_c3:
        custom_clk = st.slider("Clock Frequency (MHz)", 50, 450, 250, 25)
    with sb_c4:
        custom_taps = st.select_slider("FIR Filter Taps", options=[16, 32, 64, 128, 256], value=64)

    # Compute custom simulation
    res = calculate_hardware_metrics(custom_arch, window_length, custom_taps, custom_p, custom_clk, target_device)

    st.markdown("### 🧮 Real-Time Simulation Projections")
    r1, r2, r3, r4 = st.columns(4)
    with r1:
        st.metric("Total Latency", f"{res['t_total_ms']:.4f} ms", f"Comp: {res['t_comp_ms']:.4f} ms")
    with r2:
        st.metric("Sustained Throughput", f"{res['throughput_mbps']:.1f} Mbps", f"{res['throughput_mbps']/1000.0:.2f} Gbps")
    with r3:
        st.metric("Total Thermal Power", f"{res['power_total_w']:.2f} W", f"Dyn: {res['power_dynamic_w']:.2f} W")
    with r4:
        st.metric("Energy per Window", f"{res['energy_window_uj']:.2f} µJ", f"{res['energy_efficiency_nj_bit']:.2f} nJ/bit")

    # Resource Capacity Gauges
    st.markdown("### 🎛️ Projected Hardware Resource Slices")
    g1, g2, g3, g4 = st.columns(4)

    def make_gauge(title, val, max_val=100.0, color="#38bdf8"):
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=val,
            number={'suffix': "%"},
            title={'text': title, 'font': {'size': 14, 'color': '#94a3b8'}},
            gauge={
                'axis': {'range': [0, max_val]},
                'bar': {'color': color},
                'steps': [
                    {'range': [0, 60], 'color': "rgba(255, 255, 255, 0.05)"},
                    {'range': [60, 85], 'color': "rgba(245, 158, 11, 0.15)"},
                    {'range': [85, 100], 'color': "rgba(239, 68, 68, 0.25)"}
                ]
            }
        ))
        fig.update_layout(height=180, margin=dict(l=20, r=20, t=30, b=10), template="plotly_dark")
        return fig

    with g1:
        st.plotly_chart(make_gauge(f"LUTs ({res['lut_used']:,})", res['lut_pct'], color="#38bdf8"), use_container_width=True)
    with g2:
        st.plotly_chart(make_gauge(f"Flip-Flops ({res['ff_used']:,})", res['ff_pct'], color="#fb923c"), use_container_width=True)
    with g3:
        st.plotly_chart(make_gauge(f"BRAM Blocks ({res['bram_used']})", res['bram_pct'], color="#4ade80"), use_container_width=True)
    with g4:
        st.plotly_chart(make_gauge(f"DSP48 Slices ({res['dsp_used']})", res['dsp_pct'], color="#a855f7"), use_container_width=True)

# ==================================================================================================
# TAB 4: IEEE DATASETS & TABLES EXPLORER
# ==================================================================================================
elif mode == "📊 IEEE Datasets & Tables Explorer":
    st.subheader("📊 Research Artifacts, IEEE Tables, and Generated Datasets")

    choice = st.selectbox(
        "Select Dataset or Research Table to Inspect",
        [
            "Table 01: Dataset Summary",
            "Table 02: Signal Parameters",
            "Table 03: Model Performance",
            "Table 04: Latency Analysis",
            "Table 05: Throughput Analysis",
            "Table 06: FPGA Resource Utilization",
            "Table 07: Power Analysis",
            "Table 08: Speedup Analysis",
            "Table 09: Overall Comprehensive Comparison",
            "Executive Summary",
            "Data: Signal Windows (Segmented)",
            "Data: Spectral Features (FFT Results)",
            "Data: Generated Signal Samples (Raw Head)",
            "Data: Preprocessed Signal Samples (Head)"
        ]
    )

    t_map = {
        "Table 01: Dataset Summary": "table_01_dataset_summary",
        "Table 02: Signal Parameters": "table_02_signal_parameters",
        "Table 03: Model Performance": "table_03_model_performance",
        "Table 04: Latency Analysis": "table_04_latency_analysis",
        "Table 05: Throughput Analysis": "table_05_throughput_analysis",
        "Table 06: FPGA Resource Utilization": "table_06_fpga_resource_utilization",
        "Table 07: Power Analysis": "table_07_power_analysis",
        "Table 08: Speedup Analysis": "table_08_speedup_analysis",
        "Table 09: Overall Comprehensive Comparison": "table_09_overall_comparison",
        "Executive Summary": "summary",
        "Data: Signal Windows (Segmented)": "windows",
        "Data: Spectral Features (FFT Results)": "spectral",
        "Data: Generated Signal Samples (Raw Head)": "raw_samples",
        "Data: Preprocessed Signal Samples (Head)": "preprocessed_samples"
    }

    t_key = t_map[choice]
    df_to_show = DATA_STORE.get(t_key, None)

    if df_to_show is not None:
        if "Samples" in choice:
            st.info(f"Displaying top 500 rows of {len(df_to_show):,} total samples.")
            df_display = df_to_show.head(500)
        else:
            df_display = df_to_show

        st.dataframe(df_display, use_container_width=True)

        csv_bytes = df_to_show.to_csv(index=False).encode('utf-8')
        st.download_button(
            label=f"⬇️ Download {choice} (CSV)",
            data=csv_bytes,
            file_name=f"{t_key}.csv",
            mime="text/csv"
        )
    else:
        st.warning(f"File for {choice} not found. Please run generate_ieee_results.py first to build the datasets.")

# ==================================================================================================
# TAB 5: PUBLICATION FIGURES GALLERY
# ==================================================================================================
elif mode == "🖼️ Publication Figures Gallery":
    st.subheader("🖼️ High-Resolution Publication Figures (600 DPI, IEEE Standards)")
    st.caption("All figures formatted with Times New Roman serif typography, white backgrounds, no gridlines, and unrotated labels.")

    plots_dir = BASE_DIR / "plots"
    if plots_dir.exists():
        plot_files = sorted(list(plots_dir.glob("figure_*.png")))
        
        # Display in 2 columns
        for idx in range(0, len(plot_files), 2):
            g_col1, g_col2 = st.columns(2)
            with g_col1:
                f_path = plot_files[idx]
                st.image(str(f_path), caption=f_path.stem.replace("_", " ").title(), use_container_width=True)
            if idx + 1 < len(plot_files):
                with g_col2:
                    f_path2 = plot_files[idx + 1]
                    st.image(str(f_path2), caption=f_path2.stem.replace("_", " ").title(), use_container_width=True)
    else:
        st.warning("Plots directory not found. Please run generate_ieee_results.py to generate figures.")

# ==================================================================================================
# FOOTER
# ==================================================================================================
st.divider()
st.caption("Embedded Signal Processing Research Telemetry System | AMD/Xilinx Zynq UltraScale+ Simulation Suite")
