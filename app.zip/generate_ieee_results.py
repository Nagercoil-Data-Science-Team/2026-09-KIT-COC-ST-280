"""
====================================================================================================
The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput in Real-Time 
Embedded Communication Systems
====================================================================================================
Comprehensive Research Implementation & Experimental Evaluation Workflow

This script implements the full end-to-end signal processing and FPGA hardware modeling pipeline:
  Step 1: Communication Signal Dataset Generation (Multi-SNR, I/Q Baseband & Carrier)
  Step 2: Signal Preprocessing (Noise Filtering, Normalization, Conditioning)
  Step 3: Streaming Data Segmentation (Fixed-Length Windowing)
  Step 4: FPGA Data-Transfer Modeling (AXI4-Stream + DMA)
  Step 5: Parallel Pipelined FIR-FFT Processing (S-FPGA, P-FPGA, PP-FPGA Models)
  Step 6: FPGA-to-Host Data Transfer Modeling (AXI4-Stream + DMA)
  Step 7: Performance and Resource Evaluation (Latency, Throughput, Resources, Power)

Output Folder: FPGA_Signal_Processing_Results/
  - data/     : 4 CSV dataset files
  - tables/   : 9 IEEE-ready CSV tables
  - plots/    : 14 Publication-grade 800 DPI PNG figures (Times New Roman, no gridlines)
  - summary/  : experimental_summary.csv and README.txt
====================================================================================================
"""

import sys
import os
import math
from pathlib import Path
import numpy as np
import pandas as pd
import scipy.signal as signal
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ==================================================================================================
# REPRODUCIBILITY & GLOBAL CONFIGURATION
# ==================================================================================================
RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)

# Set publication-quality plot parameters
plt.rcParams['font.family'] = 'serif'
plt.rcParams['font.serif'] = ['Times New Roman', 'DejaVu Serif', 'Liberation Serif']
plt.rcParams['font.size'] = 12
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.titlesize'] = 15
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['axes.labelsize'] = 15
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['xtick.labelsize'] = 13
plt.rcParams['ytick.labelsize'] = 13
plt.rcParams['legend.fontsize'] = 13
plt.rcParams['figure.titlesize'] = 15
plt.rcParams['figure.titleweight'] = 'bold'
plt.rcParams['axes.facecolor'] = 'white'
plt.rcParams['figure.facecolor'] = 'white'
plt.rcParams['savefig.facecolor'] = 'white'
plt.rcParams['axes.grid'] = False

# Palette for IEEE publication (Colorblind-friendly, distinct)
COLOR_S_FPGA = '#1f77b4'   # Navy Blue
COLOR_P_FPGA = '#ff7f0e'   # Amber Orange
COLOR_PP_FPGA = '#2ca02c'  # Forest Green
COLOR_NEUTRAL = '#4a5568'  # Slate Grey
COLOR_ACCENT = '#d62728'   # Crimson Red

# ==================================================================================================
# 1. DIRECTORY INITIALIZATION
# ==================================================================================================
def setup_directories(base_dir: Path) -> dict:
    """Creates the standard output directory structure."""
    dirs = {
        'base': base_dir,
        'data': base_dir / 'data',
        'tables': base_dir / 'tables',
        'plots': base_dir / 'plots',
        'summary': base_dir / 'summary'
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs

# ==================================================================================================
# 2. STEP 1 – COMMUNICATION SIGNAL DATASET GENERATION
# ==================================================================================================
def generate_communication_signals(n_signals: int = 5, samples_per_signal: int = 4096, 
                                   fs: float = 20.0e6, fc: float = 2.5e6) -> pd.DataFrame:
    """
    Generates a reproducible, realistic synthetic communication signal dataset.
    
    Parameters:
      n_signals: Number of signal streams across distinct SNR conditions.
      samples_per_signal: Number of temporal samples per signal stream.
      fs: Sampling frequency in Hz (20 MHz).
      fc: Carrier frequency in Hz (2.5 MHz).
      
    Generates I/Q complex envelope modulated with digital symbols, upconverted to carrier,
    and corrupted by Additive White Gaussian Noise (AWGN) at SNRs: 0, 5, 10, 15, 20 dB.
    """
    snr_levels = [0.0, 5.0, 10.0, 15.0, 20.0]
    if n_signals != len(snr_levels):
        snr_levels = np.linspace(0.0, 20.0, n_signals).tolist()

    all_records = []
    sample_global_id = 0
    t = np.arange(samples_per_signal) / fs
    symbol_rate = 500e3  # 500 kBaud symbol rate
    samples_per_symbol = int(fs / symbol_rate)

    for sig_idx, snr_db in enumerate(snr_levels):
        sig_id = f"SIG_{sig_idx + 1:02d}_SNR_{int(snr_db)}dB"
        
        # Pseudo-random digital baseband symbol generation (QPSK modulation)
        n_symbols = math.ceil(samples_per_signal / samples_per_symbol) + 4
        rng = np.random.default_rng(RANDOM_SEED + sig_idx * 100)
        sym_bits = rng.integers(0, 4, size=n_symbols)
        # QPSK mapping: {0: 1+1j, 1: -1+1j, 2: -1-1j, 3: 1-1j} / sqrt(2)
        qpsk_constellation = np.array([1 + 1j, -1 + 1j, -1 - 1j, 1 - 1j]) / np.sqrt(2.0)
        symbols = qpsk_constellation[sym_bits]
        
        # Pulse shaping: Upsample and apply square-root raised-cosine (RRC) / Gaussian filter
        upsampled = np.zeros(n_symbols * samples_per_symbol, dtype=complex)
        upsampled[::samples_per_symbol] = symbols
        # Truncate to signal length
        baseband_raw = upsampled[:samples_per_signal]
        
        # Smooth baseband pulse shaping filter
        b_pulse = signal.firwin(31, cutoff=symbol_rate / (fs / 2), window=('kaiser', 5.0))
        baseband_i = signal.convolve(baseband_raw.real, b_pulse, mode='same')
        baseband_q = signal.convolve(baseband_raw.imag, b_pulse, mode='same')
        
        # RF Carrier modulation
        carrier_cos = np.cos(2 * np.pi * fc * t)
        carrier_sin = np.sin(2 * np.pi * fc * t)
        rf_clean_i = baseband_i * carrier_cos - baseband_q * carrier_sin
        rf_clean_q = baseband_i * carrier_sin + baseband_q * carrier_cos
        
        # Signal power calculation & AWGN addition
        sig_power_i = np.mean(rf_clean_i ** 2)
        sig_power_q = np.mean(rf_clean_q ** 2)
        avg_sig_power = 0.5 * (sig_power_i + sig_power_q)
        
        snr_linear = 10.0 ** (snr_db / 10.0)
        noise_power = avg_sig_power / snr_linear
        noise_std = np.sqrt(noise_power)
        
        noise_i = rng.normal(0, noise_std, size=samples_per_signal)
        noise_q = rng.normal(0, noise_std, size=samples_per_signal)
        
        noisy_i = rf_clean_i + noise_i
        noisy_q = rf_clean_q + noise_q
        
        amplitude = np.sqrt(noisy_i ** 2 + noisy_q ** 2)
        phase = np.arctan2(noisy_q, noisy_i)

        for s_idx in range(samples_per_signal):
            all_records.append({
                'sample_id': sample_global_id,
                'signal_id': sig_id,
                'time_sec': t[s_idx],
                'I': float(noisy_i[s_idx]),
                'Q': float(noisy_q[s_idx]),
                'amplitude': float(amplitude[s_idx]),
                'phase_rad': float(phase[s_idx]),
                'SNR_dB': float(snr_db)
            })
            sample_global_id += 1

    df_samples = pd.DataFrame(all_records)
    return df_samples

# ==================================================================================================
# 3. STEP 2 – SIGNAL PREPROCESSING
# ==================================================================================================
def preprocess_signals(df_raw: pd.DataFrame, fs: float = 20.0e6) -> pd.DataFrame:
    """
    Performs noise filtering, DC offset compensation, and normalization for FPGA dynamic range.
    
    Methods:
      - Anti-aliasing / bandpass noise filtering: 33-tap Hamming FIR filter.
      - DC offset removal (signal conditioning).
      - Dynamic range normalization to [-1.0, 1.0] matching FPGA fixed-point Q1.15 format.
    """
    # Design bandpass conditioning filter around carrier fc = 2.5 MHz with 1.5 MHz bandwidth
    fc = 2.5e6
    bw = 1.6e6
    low_cut = (fc - bw / 2) / (fs / 2)
    high_cut = (fc + bw / 2) / (fs / 2)
    fir_coeffs = signal.firwin(33, [low_cut, high_cut], pass_zero=False, window='hamming')

    preprocessed_records = []
    
    for sig_id, group in df_raw.groupby('signal_id', sort=False):
        i_raw = group['I'].values
        q_raw = group['Q'].values
        time_vals = group['time_sec'].values
        snr_val = group['SNR_dB'].values[0]
        sample_ids = group['sample_id'].values

        # 1. Conditioning: Remove DC bias
        i_nodc = i_raw - np.mean(i_raw)
        q_nodc = q_raw - np.mean(q_raw)

        # 2. Filtering: 33-tap conditioning filter
        i_filtered = signal.lfilter(fir_coeffs, 1.0, i_nodc)
        q_filtered = signal.lfilter(fir_coeffs, 1.0, q_nodc)

        # 3. Normalization: Scale to [-1.0, 1.0] for FPGA fixed-point representation
        max_val = max(np.max(np.abs(i_filtered)), np.max(np.abs(q_filtered)), 1e-9)
        i_norm = i_filtered / max_val
        q_norm = q_filtered / max_val
        
        amp_norm = np.sqrt(i_norm ** 2 + q_norm ** 2)
        phase_deg = np.rad2deg(np.arctan2(q_norm, i_norm))

        for idx in range(len(group)):
            preprocessed_records.append({
                'sample_id': sample_ids[idx],
                'signal_id': sig_id,
                'time_sec': time_vals[idx],
                'I_filtered': float(i_filtered[idx]),
                'Q_filtered': float(q_filtered[idx]),
                'I_norm': float(i_norm[idx]),
                'Q_norm': float(q_norm[idx]),
                'amplitude_norm': float(amp_norm[idx]),
                'phase_deg': float(phase_deg[idx]),
                'SNR_dB': float(snr_val)
            })

    df_preprocessed = pd.DataFrame(preprocessed_records)
    return df_preprocessed

# ==================================================================================================
# 4. STEP 3 – STREAMING DATA SEGMENTATION (FIXED-LENGTH WINDOWING)
# ==================================================================================================
def segment_streaming_data(df_preprocessed: pd.DataFrame, window_length: int = 512) -> pd.DataFrame:
    """
    Divides streaming preprocessed signals into fixed-length windows for FPGA DMA transmission.
    
    For each window computes:
      - window ID, signal ID, start index, end index, window length
      - mean amplitude, RMS, signal power
    """
    window_records = []
    window_global_id = 0

    for sig_id, group in df_preprocessed.groupby('signal_id', sort=False):
        n_samples = len(group)
        n_windows = n_samples // window_length
        snr_val = group['SNR_dB'].values[0]
        
        amp_norm = group['amplitude_norm'].values

        for w_idx in range(n_windows):
            start_idx = w_idx * window_length
            end_idx = start_idx + window_length
            win_amp = amp_norm[start_idx:end_idx]

            mean_amp = float(np.mean(win_amp))
            rms_val = float(np.sqrt(np.mean(win_amp ** 2)))
            power_val = float(rms_val ** 2)

            window_records.append({
                'window_id': window_global_id,
                'signal_id': sig_id,
                'start_index': start_idx,
                'end_index': end_idx,
                'window_length': window_length,
                'mean_amplitude': round(mean_amp, 6),
                'rms': round(rms_val, 6),
                'signal_power': round(power_val, 6),
                'SNR_dB': float(snr_val)
            })
            window_global_id += 1

    df_windows = pd.DataFrame(window_records)
    return df_windows

# ==================================================================================================
# 5. STEP 4 & 5 – FIR FILTERING + FFT SPECTRAL EXTRACTION
# ==================================================================================================
def process_fir_fft(df_preprocessed: pd.DataFrame, window_length: int = 512, 
                    fs: float = 20.0e6) -> pd.DataFrame:
    """
    Applies a 64-tap complex FIR filter followed by a 512-point FFT on each window.
    Extracts spectral characteristics: dominant frequency, peak magnitude, spectral power, 
    bandwidth (-3 dB), RMS, and processing window size.
    """
    # Realistic 64-tap lowpass/bandpass FIR filter coefficients
    fir_taps = 64
    b_fir = signal.firwin(fir_taps, cutoff=3.5e6 / (fs / 2), window='hamming')

    spectral_records = []
    window_global_id = 0

    freqs = np.fft.fftfreq(window_length, d=1.0 / fs)
    pos_mask = freqs >= 0
    pos_freqs = freqs[pos_mask]

    for sig_id, group in df_preprocessed.groupby('signal_id', sort=False):
        n_samples = len(group)
        n_windows = n_samples // window_length
        snr_val = group['SNR_dB'].values[0]

        i_vals = group['I_norm'].values
        q_vals = group['Q_norm'].values
        complex_signal = i_vals + 1j * q_vals

        for w_idx in range(n_windows):
            start_idx = w_idx * window_length
            end_idx = start_idx + window_length
            chunk = complex_signal[start_idx:end_idx]

            # 1. 64-tap FIR filter application
            filtered_chunk = signal.lfilter(b_fir, 1.0, chunk)

            # 2. 512-point complex FFT with Hann windowing for spectral containment
            win_hann = np.hanning(window_length)
            fft_result = np.fft.fft(filtered_chunk * win_hann, n=window_length)
            
            # Positive frequency spectrum
            pos_fft = np.abs(fft_result[pos_mask])
            pos_power = pos_fft ** 2

            peak_idx = np.argmax(pos_fft)
            dominant_freq_mhz = float(pos_freqs[peak_idx] / 1e6)
            peak_mag = float(pos_fft[peak_idx])
            spec_power = float(np.sum(pos_power) / window_length)
            rms_spec = float(np.sqrt(np.mean(np.abs(filtered_chunk) ** 2)))

            # -3 dB bandwidth estimation
            half_power = peak_mag / np.sqrt(2.0)
            above_half = np.where(pos_fft >= half_power)[0]
            if len(above_half) > 1:
                bw_mhz = float((pos_freqs[above_half[-1]] - pos_freqs[above_half[0]]) / 1e6)
            else:
                bw_mhz = float((pos_freqs[1] - pos_freqs[0]) / 1e6)

            spectral_records.append({
                'window_id': window_global_id,
                'signal_id': sig_id,
                'dominant_frequency_MHz': round(dominant_freq_mhz, 4),
                'peak_magnitude': round(peak_mag, 4),
                'spectral_power': round(spec_power, 4),
                'bandwidth_MHz': round(bw_mhz, 4),
                'rms': round(rms_spec, 4),
                'processing_window_size': window_length,
                'SNR_dB': float(snr_val)
            })
            window_global_id += 1

    df_spectral = pd.DataFrame(spectral_records)
    return df_spectral

# ==================================================================================================
# 6. STEPS 4, 5, 6, 7 – FPGA HARDWARE SIMULATION & ARCHITECTURAL MODELING
# ==================================================================================================
"""
ARCHITECTURAL SPECIFICATIONS & SIMULATION ASSUMPTIONS:
Reference Device: AMD/Xilinx Zynq UltraScale+ XCZU9EG (FFVC900, -2 speed grade)
Total Resources Available:
  - CLB Look-Up Tables (LUTs): 274,080
  - CLB Flip-Flops (FFs):     548,160
  - Block RAM (BRAM 36Kb):        912 blocks (32.8 Mb total)
  - DSP48E2 Slices:             2,520 slices
  - Nominal Core Voltage:        0.85 V

1. AXI4-Stream + DMA Modeling:
   - Host-to-FPGA (H2F) & FPGA-to-Host (F2H) via AXI4-Stream Direct Memory Access.
   - Bus width: 64-bit (8 bytes/cycle) operating at AXI clock frequency F_axi = 200 MHz.
   - Payload per window: 512 complex samples * 4 bytes (16-bit I + 16-bit Q) = 2,048 bytes (2 KB).
   - DMA setup overhead: ~1.50 us (scatter-gather descriptor management, interrupt handling).
   - Transfer cycles: 2,048 bytes / 8 bytes/cycle = 256 cycles = 1.28 us at 200 MHz.
   - Base DMA transfer latency: t_dma = 1.50 us + 1.28 us = 2.78 us per transfer (H2F and F2H).

2. S-FPGA (Sequential FPGA Model):
   - Architecture: Minimal area, time-multiplexed single-MAC architecture.
   - Max Clock Frequency: 150.0 MHz (critical paths unpipelined through accumulator).
   - FIR filtering: 64 taps sequential execution across 512 samples = 512 * 64 = 32,768 cycles.
   - Radix-2 sequential FFT: (N/2)*log2(N) = 256 * 9 = 2,304 butterflies. With 1 butterfly engine
     executing 4 cycles per butterfly = 9,216 cycles.
   - Total computation cycles: 32,768 + 9,216 = 41,984 cycles.
   - Execution Model: Non-overlapped batch mode:
     Total Latency = T_H2F + T_FIR + T_FFT + T_F2H.
   - Resources: 14,250 LUTs (5.20%), 16,400 FFs (2.99%), 18 BRAMs (1.97%), 6 DSPs (0.24%).
   - Power: Static 1.10 W, Dynamic 0.55 W, Total 1.65 W.

3. P-FPGA (Parallel FPGA Model):
   - Architecture: Spatial parallelism with P = 8 parallel processing channels/engines.
   - Max Clock Frequency: 200.0 MHz.
   - FIR filtering: 8-way parallel MAC array. Cycles = (512 * 64) / 8 + 16 (setup) = 4,112 cycles.
   - Radix-2 multi-bank parallel FFT: 8 parallel butterfly units. Cycles = (2,304 * 4) / 8 + 16 = 1,168 cycles.
   - Total computation cycles: 4,112 + 1,168 = 5,280 cycles.
   - Execution Model: Block-level sequential transfer and parallel compute:
     Total Latency = T_H2F + T_comp + T_F2H.
   - Resources: 48,800 LUTs (17.73%), 52,300 FFs (9.54%), 46 BRAMs (5.04%), 72 DSPs (2.86%).
   - Power: Static 1.15 W, Dynamic 1.95 W, Total 3.10 W.

4. PP-FPGA (Parallel Pipelined FPGA Model):
   - Architecture: P = 8 parallel channels with deep multi-stage systolic FIR and 
     pipelined streaming Radix-2^2 Single-path Delay Feedback (SDF) FFT architecture.
   - Max Clock Frequency: 250.0 MHz (fine-grained pipelined registers shorten critical paths).
   - Execution Model: Fully overlapped 4-stage pipeline (H2F DMA -> Systolic FIR -> SDF FFT -> F2H DMA).
   - Pipeline Initiation Interval: II = 64 cycles per window (processes 8 samples/cycle concurrently).
   - Computation Latency per window: 
     Pipelined FIR depth (64 cycles) + SDF FFT latency (100 cycles) + output framing = 228 cycles.
     At 250 MHz: T_comp = 228 / (250e6) = 0.912 us.
   - Overlapped streaming throughput is governed by max stage interval max(T_dma, T_compute) = 2.60 us.
   - End-to-end window latency: ~5.82 us.
   - Resources: 92,400 LUTs (33.71%), 138,500 FFs (25.27%), 98 BRAMs (10.75%), 256 DSPs (10.16%).
   - Power: Static 1.22 W, Dynamic 3.63 W, Total 4.85 W.
"""

def simulate_fpga_models(df_windows: pd.DataFrame, n_runs: int = 20) -> dict:
    """
    Performs comprehensive statistical evaluation of S-FPGA, P-FPGA, and PP-FPGA models
    across repeated independent experimental runs with realistic system jitter and DMA contention.
    """
    total_samples = len(df_windows) * df_windows['window_length'].iloc[0]
    total_bits = total_samples * 32  # 32 bits per complex sample (16-bit I + 16-bit Q)
    window_bits = df_windows['window_length'].iloc[0] * 32
    n_windows = len(df_windows)

    # Reference hardware limits
    hw_limits = {
        'LUT_total': 274080,
        'FF_total': 548160,
        'BRAM_total': 912,
        'DSP_total': 2520
    }

    models_config = {
        'S-FPGA': {
            'name': 'Sequential FPGA (S-FPGA)',
            'f_clk_mhz': 150.0,
            'fir_cycles': 32768,
            'fft_cycles': 9216,
            'pipelined': False,
            'overlapped': False,
            'lut_base': 14250,
            'ff_base': 16400,
            'bram_base': 18,
            'dsp_base': 6,
            'p_static': 1.10,
            'p_dyn_base': 0.55
        },
        'P-FPGA': {
            'name': 'Parallel FPGA (P-FPGA)',
            'f_clk_mhz': 200.0,
            'fir_cycles': 4112,
            'fft_cycles': 1168,
            'pipelined': False,
            'overlapped': False,
            'lut_base': 48800,
            'ff_base': 52300,
            'bram_base': 46,
            'dsp_base': 72,
            'p_static': 1.15,
            'p_dyn_base': 1.95
        },
        'PP-FPGA': {
            'name': 'Parallel Pipelined FPGA (PP-FPGA)',
            'f_clk_mhz': 250.0,
            'fir_cycles': 128,
            'fft_cycles': 100,
            'pipelined': True,
            'overlapped': True,
            'lut_base': 92400,
            'ff_base': 138500,
            'bram_base': 98,
            'dsp_base': 256,
            'p_static': 1.22,
            'p_dyn_base': 3.63
        }
    }

    results_by_run = {m: [] for m in models_config}

    for run_idx in range(n_runs):
        rng = np.random.default_rng(RANDOM_SEED + run_idx * 50)
        
        # System DMA jitter: normal distribution +/- 4%
        dma_jitter = rng.normal(0, 0.04)
        h2f_latency_ms = (2.78 * (1.0 + dma_jitter)) / 1000.0   # ~0.00278 ms
        f2h_latency_ms = (2.78 * (1.0 + dma_jitter)) / 1000.0

        for m_key, cfg in models_config.items():
            f_clk = cfg['f_clk_mhz'] * 1e6
            clk_jitter = rng.normal(0, 0.005)  # 0.5% clock frequency jitter
            effective_f_clk = f_clk * (1.0 + clk_jitter)

            t_fir_ms = (cfg['fir_cycles'] / effective_f_clk) * 1000.0
            t_fft_ms = (cfg['fft_cycles'] / effective_f_clk) * 1000.0
            t_comp_ms = t_fir_ms + t_fft_ms

            if not cfg['overlapped']:
                # Non-overlapped sequential sum
                t_total_per_window_ms = h2f_latency_ms + t_comp_ms + f2h_latency_ms
                t_total_dataset_ms = t_total_per_window_ms * n_windows
                effective_throughput_mbps = (window_bits / (t_total_per_window_ms * 1e-3)) / 1e6
            else:
                # Fully overlapped 4-stage pipeline
                # Startup latency (fill pipeline) + n_windows * max(stage_delay)
                stage_delays = [h2f_latency_ms, t_fir_ms, t_fft_ms, f2h_latency_ms]
                max_stage_ms = max(stage_delays)
                pipeline_fill_ms = sum(stage_delays)
                t_total_dataset_ms = pipeline_fill_ms + (n_windows - 1) * max_stage_ms
                t_total_per_window_ms = t_total_dataset_ms / n_windows
                effective_throughput_mbps = (window_bits / (max_stage_ms * 1e-3)) / 1e6

            # Realistic resource variation with synthesis seed / routing variation (+/- 0.8%)
            res_var = rng.normal(0, 0.008)
            lut_used = int(cfg['lut_base'] * (1.0 + res_var))
            ff_used = int(cfg['ff_base'] * (1.0 + res_var))
            bram_used = int(cfg['bram_base'])
            dsp_used = int(cfg['dsp_base'])

            lut_pct = (lut_used / hw_limits['LUT_total']) * 100.0
            ff_pct = (ff_used / hw_limits['FF_total']) * 100.0
            bram_pct = (bram_used / hw_limits['BRAM_total']) * 100.0
            dsp_pct = (dsp_used / hw_limits['DSP_total']) * 100.0

            # Power modeling: Static + Dynamic (scales with clock frequency & switching activity)
            p_dyn = cfg['p_dyn_base'] * (effective_f_clk / f_clk) * (1.0 + rng.normal(0, 0.015))
            p_total = cfg['p_static'] + p_dyn
            energy_per_win_uj = p_total * (t_total_per_window_ms * 1e-3) * 1e6

            results_by_run[m_key].append({
                'run_id': run_idx + 1,
                'model': m_key,
                'model_name': cfg['name'],
                'f_clk_mhz': cfg['f_clk_mhz'],
                'h2f_latency_ms': h2f_latency_ms,
                'fir_latency_ms': t_fir_ms,
                'fft_latency_ms': t_fft_ms,
                'computation_latency_ms': t_comp_ms,
                'f2h_latency_ms': f2h_latency_ms,
                'total_latency_ms': t_total_per_window_ms,
                'throughput_mbps': effective_throughput_mbps,
                'lut_used': lut_used,
                'lut_pct': lut_pct,
                'ff_used': ff_used,
                'ff_pct': ff_pct,
                'bram_used': bram_used,
                'bram_pct': bram_pct,
                'dsp_used': dsp_used,
                'dsp_pct': dsp_pct,
                'p_static_w': cfg['p_static'],
                'p_dynamic_w': p_dyn,
                'p_total_w': p_total,
                'energy_per_window_uj': energy_per_win_uj
            })

    # Speedup calculation relative to S-FPGA for each run
    for r_idx in range(n_runs):
        s_lat = results_by_run['S-FPGA'][r_idx]['total_latency_ms']
        s_comp = results_by_run['S-FPGA'][r_idx]['computation_latency_ms']
        s_fir = results_by_run['S-FPGA'][r_idx]['fir_latency_ms']
        s_fft = results_by_run['S-FPGA'][r_idx]['fft_latency_ms']

        for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
            cur = results_by_run[m_key][r_idx]
            cur['speedup_total'] = s_lat / cur['total_latency_ms']
            cur['speedup_comp'] = s_comp / cur['computation_latency_ms']
            cur['speedup_fir'] = s_fir / cur['fir_latency_ms']
            cur['speedup_fft'] = s_fft / cur['fft_latency_ms']

    return {
        'runs_data': results_by_run,
        'hw_limits': hw_limits,
        'total_samples': total_samples,
        'total_bits': total_bits,
        'n_windows': n_windows
    }

# ==================================================================================================
# 7. TABLE GENERATION (9 IEEE TABLES + 1 CONSOLIDATED SUMMARY)
# ==================================================================================================
def generate_tables(output_dir: Path, sim_results: dict, df_raw: pd.DataFrame, 
                    df_pre: pd.DataFrame, df_win: pd.DataFrame, df_spec: pd.DataFrame):
    """
    Creates all 9 IEEE-ready CSV tables and the consolidated summary.
    """
    tables_dir = output_dir / 'tables'
    summary_dir = output_dir / 'summary'

    runs_data = sim_results['runs_data']
    hw_limits = sim_results['hw_limits']

    # Convert runs data to comprehensive DataFrames
    df_runs = pd.concat([pd.DataFrame(runs_data[m]) for m in runs_data], ignore_index=True)

    # ----------------------------------------------------------------------------------------------
    # Table 1: Dataset Summary
    # ----------------------------------------------------------------------------------------------
    t1_data = [
        {"Parameter": "Total Generated Samples", "Value": f"{len(df_raw):,}", "Unit": "Samples"},
        {"Parameter": "Signal Streams (Conditions)", "Value": str(df_raw['signal_id'].nunique()), "Unit": "Streams"},
        {"Parameter": "Samples per Signal Stream", "Value": f"{len(df_raw) // df_raw['signal_id'].nunique():,}", "Unit": "Samples"},
        {"Parameter": "Sampling Frequency (Fs)", "Value": "20.00", "Unit": "MHz"},
        {"Parameter": "Carrier Frequency (Fc)", "Value": "2.50", "Unit": "MHz"},
        {"Parameter": "Symbol Rate", "Value": "500.00", "Unit": "kBaud"},
        {"Parameter": "Modulation Scheme", "Value": "QPSK / Complex I-Q", "Unit": "Format"},
        {"Parameter": "SNR Range", "Value": "0.00 to 20.00", "Unit": "dB"},
        {"Parameter": "SNR Step Size", "Value": "5.00", "Unit": "dB"},
        {"Parameter": "Signal Stream Duration", "Value": "0.2048", "Unit": "ms"},
        {"Parameter": "Total Dataset Duration", "Value": "1.0240", "Unit": "ms"},
        {"Parameter": "Sample Bit Resolution", "Value": "32 (16-bit I + 16-bit Q)", "Unit": "Bits/Sample"},
        {"Parameter": "Total Dataset Size", "Value": f"{len(df_raw) * 4 / 1024:.2f}", "Unit": "KB"}
    ]
    pd.DataFrame(t1_data).to_csv(tables_dir / 'table_01_dataset_summary.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 2: Signal Parameters & Preprocessing Configuration
    # ----------------------------------------------------------------------------------------------
    t2_data = [
        {"Parameter": "Conditioning Filter Type", "Specification": "Bandpass FIR Filter", "Design Method": "Hamming Window"},
        {"Parameter": "Conditioning Filter Taps", "Specification": "33", "Design Method": "Linear-Phase Direct-Form"},
        {"Parameter": "Conditioning Cutoff Band", "Specification": "1.70 to 3.30 MHz", "Design Method": "fc +/- 800 kHz"},
        {"Parameter": "Dynamic Range Normalization", "Specification": "[-1.0, 1.0]", "Design Method": "Q1.15 Fixed-Point Scaled"},
        {"Parameter": "Streaming Windowing Method", "Specification": "Fixed-Length Rectangular", "Design Method": "Contiguous Streaming"},
        {"Parameter": "Window Length (N)", "Specification": "512", "Design Method": "Samples/Window"},
        {"Parameter": "Total Streaming Windows", "Specification": str(len(df_win)), "Design Method": "40 Continuous Windows"},
        {"Parameter": "Processing FIR Filter Taps", "Specification": "64", "Design Method": "Symmetric Lowpass FIR"},
        {"Parameter": "Processing FIR Cutoff", "Specification": "3.50 MHz", "Design Method": "Hamming Windowed"},
        {"Parameter": "Spectral FFT Transform Size", "Specification": "512", "Design Method": "Complex Radix-2 / Radix-2^2"},
        {"Parameter": "Spectral Windowing", "Specification": "Hann Window", "Design Method": "Side-Lobe Attenuation"}
    ]
    pd.DataFrame(t2_data).to_csv(tables_dir / 'table_02_signal_parameters.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 3: Model Performance (Aggregated across runs: Mean, Std, Min, Max)
    # ----------------------------------------------------------------------------------------------
    t3_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        t3_rows.append({
            "Architecture Model": sub['model_name'].iloc[0],
            "Clock Frequency (MHz)": f"{sub['f_clk_mhz'].iloc[0]:.1f}",
            "Comp Latency Mean (ms)": round(sub['computation_latency_ms'].mean(), 6),
            "Comp Latency Std (ms)": round(sub['computation_latency_ms'].std(), 6),
            "Total Latency Mean (ms)": round(sub['total_latency_ms'].mean(), 6),
            "Total Latency Std (ms)": round(sub['total_latency_ms'].std(), 6),
            "Throughput Mean (Mbps)": round(sub['throughput_mbps'].mean(), 2),
            "Throughput Std (Mbps)": round(sub['throughput_mbps'].std(), 2),
            "Throughput Min (Mbps)": round(sub['throughput_mbps'].min(), 2),
            "Throughput Max (Mbps)": round(sub['throughput_mbps'].max(), 2),
            "Overall Speedup Mean": round(sub['speedup_total'].mean(), 2),
            "Total Power Mean (W)": round(sub['p_total_w'].mean(), 3)
        })
    pd.DataFrame(t3_rows).to_csv(tables_dir / 'table_03_model_performance.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 4: Latency Analysis (Breakdown across stages: H2F, FIR, FFT, F2H, Total)
    # ----------------------------------------------------------------------------------------------
    t4_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        t4_rows.append({
            "Architecture": sub['model_name'].iloc[0],
            "H2F DMA Latency Mean (ms)": round(sub['h2f_latency_ms'].mean(), 6),
            "H2F DMA Latency Std (ms)": round(sub['h2f_latency_ms'].std(), 6),
            "FIR Filtering Latency Mean (ms)": round(sub['fir_latency_ms'].mean(), 6),
            "FIR Filtering Latency Std (ms)": round(sub['fir_latency_ms'].std(), 6),
            "FFT Processing Latency Mean (ms)": round(sub['fft_latency_ms'].mean(), 6),
            "FFT Processing Latency Std (ms)": round(sub['fft_latency_ms'].std(), 6),
            "F2H DMA Latency Mean (ms)": round(sub['f2h_latency_ms'].mean(), 6),
            "F2H DMA Latency Std (ms)": round(sub['f2h_latency_ms'].std(), 6),
            "End-to-End Latency Mean (ms)": round(sub['total_latency_ms'].mean(), 6),
            "End-to-End Latency Std (ms)": round(sub['total_latency_ms'].std(), 6)
        })
    pd.DataFrame(t4_rows).to_csv(tables_dir / 'table_04_latency_analysis.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 5: Throughput Analysis across SNR conditions & Window Lengths
    # ----------------------------------------------------------------------------------------------
    # Model scaling across distinct window lengths N in [128, 256, 512, 1024, 2048]
    t5_rows = []
    win_sizes = [128, 256, 512, 1024, 2048]
    for w_size in win_sizes:
        w_bits = w_size * 32
        # S-FPGA
        s_cycles = (w_size * 64) + ((w_size // 2) * int(np.log2(w_size)) * 4)
        s_lat = (2.78e-6 * 2) + (s_cycles / 150e6)
        s_th = (w_bits / s_lat) / 1e6

        # P-FPGA (P=8)
        p_cycles = ((w_size * 64) / 8) + (((w_size // 2) * int(np.log2(w_size)) * 4) / 8) + 32
        p_lat = (2.78e-6 * 2) + (p_cycles / 200e6)
        p_th = (w_bits / p_lat) / 1e6

        # PP-FPGA (Pipelined Overlapped)
        pp_stage_lat = max(2.78e-6, (w_size / 8) / 250e6)
        pp_th = (w_bits / pp_stage_lat) / 1e6

        t5_rows.append({
            "Window Size (Samples)": w_size,
            "Window Payload (Bytes)": w_size * 4,
            "S-FPGA Throughput (Mbps)": round(s_th, 2),
            "P-FPGA Throughput (Mbps)": round(p_th, 2),
            "PP-FPGA Throughput (Mbps)": round(pp_th, 2),
            "PP-FPGA Gain vs S-FPGA (x)": round(pp_th / s_th, 2)
        })
    pd.DataFrame(t5_rows).to_csv(tables_dir / 'table_05_throughput_analysis.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 6: FPGA Resource Utilization
    # ----------------------------------------------------------------------------------------------
    t6_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        t6_rows.append({
            "Architecture": sub['model_name'].iloc[0],
            "LUTs Used (Count)": int(sub['lut_used'].mean()),
            "LUT Utilization (%)": round(sub['lut_pct'].mean(), 2),
            "Flip-Flops Used (Count)": int(sub['ff_used'].mean()),
            "Flip-Flop Utilization (%)": round(sub['ff_pct'].mean(), 2),
            "BRAM Blocks (36Kb)": int(sub['bram_used'].mean()),
            "BRAM Utilization (%)": round(sub['bram_pct'].mean(), 2),
            "DSP48E2 Slices": int(sub['dsp_used'].mean()),
            "DSP Utilization (%)": round(sub['dsp_pct'].mean(), 2)
        })
    # Add Total Device Available row
    t6_rows.append({
        "Architecture": "Total Device Available (XCZU9EG)",
        "LUTs Used (Count)": hw_limits['LUT_total'],
        "LUT Utilization (%)": 100.00,
        "Flip-Flops Used (Count)": hw_limits['FF_total'],
        "Flip-Flop Utilization (%)": 100.00,
        "BRAM Blocks (36Kb)": hw_limits['BRAM_total'],
        "BRAM Utilization (%)": 100.00,
        "DSP48E2 Slices": hw_limits['DSP_total'],
        "DSP Utilization (%)": 100.00
    })
    pd.DataFrame(t6_rows).to_csv(tables_dir / 'table_06_fpga_resource_utilization.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 7: Power Analysis & Energy Efficiency
    # ----------------------------------------------------------------------------------------------
    t7_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        p_tot = sub['p_total_w'].mean()
        t_lat = sub['total_latency_ms'].mean()
        th_mbps = sub['throughput_mbps'].mean()
        energy_win = sub['energy_per_window_uj'].mean()
        # Energy per bit in nJ/bit = (P_total * T_win) / (512 * 32)
        energy_bit_nj = (p_tot * (t_lat * 1e-3) / (512 * 32)) * 1e9

        t7_rows.append({
            "Architecture": sub['model_name'].iloc[0],
            "Static Power (W)": round(sub['p_static_w'].mean(), 3),
            "Dynamic Power (W)": round(sub['p_dynamic_w'].mean(), 3),
            "Total Power (W)": round(p_tot, 3),
            "Energy per Window (uJ)": round(energy_win, 3),
            "Energy Efficiency (nJ/bit)": round(energy_bit_nj, 3),
            "Power-Delay Product (uJ)": round(p_tot * t_lat * 1e3, 3)
        })
    pd.DataFrame(t7_rows).to_csv(tables_dir / 'table_07_power_analysis.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 8: Speedup Analysis
    # ----------------------------------------------------------------------------------------------
    t8_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        t8_rows.append({
            "Architecture": sub['model_name'].iloc[0],
            "FIR Speedup Mean": round(sub['speedup_fir'].mean(), 2),
            "FFT Speedup Mean": round(sub['speedup_fft'].mean(), 2),
            "Computation Speedup Mean": round(sub['speedup_comp'].mean(), 2),
            "Overall Latency Speedup Mean": round(sub['speedup_total'].mean(), 2),
            "Speedup Min": round(sub['speedup_total'].min(), 2),
            "Speedup Max": round(sub['speedup_total'].max(), 2)
        })
    pd.DataFrame(t8_rows).to_csv(tables_dir / 'table_08_speedup_analysis.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Table 9: Overall Comprehensive IEEE Comparison Table
    # ----------------------------------------------------------------------------------------------
    t9_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        t9_rows.append({
            "Model": m_key,
            "Full Architecture Name": sub['model_name'].iloc[0],
            "Operating Freq (MHz)": f"{sub['f_clk_mhz'].iloc[0]:.0f}",
            "H2F+F2H Transfer (ms)": f"{sub['h2f_latency_ms'].mean() + sub['f2h_latency_ms'].mean():.6f}",
            "Computation Latency (ms)": f"{sub['computation_latency_ms'].mean():.6f}",
            "Total Window Latency (ms)": f"{sub['total_latency_ms'].mean():.6f}",
            "Throughput (Mbps)": f"{sub['throughput_mbps'].mean():.2f}",
            "Speedup vs S-FPGA": f"{sub['speedup_total'].mean():.2f}x",
            "LUT Util (%)": f"{sub['lut_pct'].mean():.2f}%",
            "FF Util (%)": f"{sub['ff_pct'].mean():.2f}%",
            "BRAM Util (%)": f"{sub['bram_pct'].mean():.2f}%",
            "DSP Util (%)": f"{sub['dsp_pct'].mean():.2f}%",
            "Total Power (W)": f"{sub['p_total_w'].mean():.3f}",
            "Energy/Window (uJ)": f"{sub['energy_per_window_uj'].mean():.3f}"
        })
    pd.DataFrame(t9_rows).to_csv(tables_dir / 'table_09_overall_comparison.csv', index=False)

    # ----------------------------------------------------------------------------------------------
    # Executive Summary: summary/experimental_summary.csv
    # ----------------------------------------------------------------------------------------------
    summary_rows = []
    for m_key in ['S-FPGA', 'P-FPGA', 'PP-FPGA']:
        sub = df_runs[df_runs['model'] == m_key]
        summary_rows.append({
            "Architecture": m_key,
            "Clock_Frequency_MHz": sub['f_clk_mhz'].iloc[0],
            "Total_Latency_ms_Mean": round(sub['total_latency_ms'].mean(), 6),
            "Throughput_Mbps_Mean": round(sub['throughput_mbps'].mean(), 2),
            "Speedup_vs_Sequential": round(sub['speedup_total'].mean(), 2),
            "DSP_Utilization_Pct": round(sub['dsp_pct'].mean(), 2),
            "LUT_Utilization_Pct": round(sub['lut_pct'].mean(), 2),
            "Power_Consumption_W": round(sub['p_total_w'].mean(), 3),
            "Energy_per_Window_uJ": round(sub['energy_per_window_uj'].mean(), 3)
        })
    pd.DataFrame(summary_rows).to_csv(summary_dir / 'experimental_summary.csv', index=False)

# ==================================================================================================
# 8. PUBLICATION PLOTS (14 HIGH-RESOLUTION FIGURES AT 800 DPI)
# ==================================================================================================
def generate_plots(output_dir: Path, sim_results: dict, df_raw: pd.DataFrame, 
                   df_pre: pd.DataFrame, df_win: pd.DataFrame, df_spec: pd.DataFrame):
    """
    Generates 14 publication-grade figures in PNG format:
      - 800 DPI
      - Times New Roman font
      - White background
      - No gridlines
      - No 3D plots
      - Unrotated, clear x-axis labels with wrapping
      - Clear units and legends
    """
    plots_dir = output_dir / 'plots'
    runs_data = sim_results['runs_data']
    df_runs = pd.concat([pd.DataFrame(runs_data[m]) for m in runs_data], ignore_index=True)

    arch_labels = ["Sequential\nFPGA (S-FPGA)", "Parallel\nFPGA (P-FPGA)", "Parallel Pipelined\nFPGA (PP-FPGA)"]
    models = ['S-FPGA', 'P-FPGA', 'PP-FPGA']
    model_colors = [COLOR_S_FPGA, COLOR_P_FPGA, COLOR_PP_FPGA]

    # Helper function to save cleanly
    def save_fig(fig, filename):
        fig.tight_layout()
        fig.savefig(plots_dir / filename, dpi=800, bbox_inches='tight', facecolor='white')
        plt.close(fig)

    # ----------------------------------------------------------------------------------------------
    # Figure 1: Raw Communication Signal (I and Q components, SNR = 10 dB)
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.5), dpi=800)
    sig_subset = df_raw[df_raw['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:300]
    t_us = sig_subset['time_sec'].values * 1e6
    ax.plot(t_us, sig_subset['I'].values, label='In-phase (I) Component', color='#1f77b4', linewidth=1.2)
    ax.plot(t_us, sig_subset['Q'].values, label='Quadrature (Q) Component', color='#ff7f0e', linewidth=1.2, linestyle='--')
    ax.plot(t_us, sig_subset['amplitude'].values, label='Signal Envelope', color='#2ca02c', linewidth=1.0, alpha=0.8)
    ax.set_title('Generated Raw Communication Signal Waveform (SNR = 10 dB)')
    ax.set_xlabel('Time (\u03bcs)')
    ax.set_ylabel('Amplitude (V)')
    ax.legend(loc='upper right', frameon=True, edgecolor='#cccccc')
    ax.grid(False)
    save_fig(fig, 'figure_01_raw_signal.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 2: Preprocessed Communication Signal
    # ----------------------------------------------------------------------------------------------
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(7.5, 5.5), dpi=800, sharex=True)
    raw_sub = df_raw[df_raw['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:250]
    pre_sub = df_pre[df_pre['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:250]
    t_sub_us = raw_sub['time_sec'].values * 1e6

    ax1.plot(t_sub_us, raw_sub['I'].values, color='#d62728', linewidth=1.1, label='Raw Noisy Signal (I)')
    ax1.set_ylabel('Raw Amplitude (V)')
    ax1.set_title('Signal Preprocessing and Conditioning Comparison')
    ax1.legend(loc='upper right', frameon=True, edgecolor='#cccccc')
    ax1.grid(False)

    ax2.plot(t_sub_us, pre_sub['I_norm'].values, color='#1f77b4', linewidth=1.2, label='Filtered & Normalized Signal (I)')
    ax2.plot(t_sub_us, pre_sub['amplitude_norm'].values, color='#2ca02c', linewidth=1.0, linestyle=':', label='Normalized Envelope')
    ax2.set_xlabel('Time (\u03bcs)')
    ax2.set_ylabel('Normalized Amplitude')
    ax2.legend(loc='upper right', frameon=True, edgecolor='#cccccc')
    ax2.grid(False)
    save_fig(fig, 'figure_02_preprocessed_signal.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 3: Signal-Window Segmentation
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.5), dpi=800)
    # Plot first 4 windows (2048 samples) of SIG_03
    win_sig_samples = df_pre[df_pre['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:2048]
    t_win_us = win_sig_samples['time_sec'].values * 1e6
    ax.plot(t_win_us, win_sig_samples['I_norm'].values, color='#4a5568', alpha=0.6, linewidth=0.8, label='Normalized Signal I(t)')

    # Add vertical window boundaries
    win_len = 512
    for w_i in range(1, 4):
        bound_t = t_win_us[w_i * win_len]
        ax.axvline(x=bound_t, color='#d62728', linestyle='--', linewidth=1.3)

    # Highlight windows
    win_subset = df_win[df_win['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:4]
    for idx, row in win_subset.iterrows():
        mid_idx = int(row['start_index'] + win_len / 2)
        mid_t = t_win_us[mid_idx]
        rms_val = row['rms']
        ax.hlines(y=rms_val, xmin=t_win_us[row['start_index']], xmax=t_win_us[row['end_index'] - 1], 
                  color='#2ca02c', linewidth=2.0)
        ax.text(mid_t, 1.05, f"Window {int(row['window_id'] % 8 + 1)}\nRMS={rms_val:.3f}", 
                ha='center', va='bottom', fontsize=8.5, weight='bold', color='#1a202c')

    ax.set_ylim(-1.2, 1.45)
    ax.set_title('Fixed-Length Streaming Data Segmentation (N = 512)')
    ax.set_xlabel('Time (\u03bcs)')
    ax.set_ylabel('Normalized Amplitude')
    ax.grid(False)
    save_fig(fig, 'figure_03_signal_windowing.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 4: FFT Spectrum Response
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.5), dpi=800)
    # Compute representative FFT on Window 0 of SIG_03
    win0_sub = df_pre[df_pre['signal_id'] == 'SIG_03_SNR_10dB'].iloc[:512]
    c_sig = (win0_sub['I_norm'].values + 1j * win0_sub['Q_norm'].values) * np.hanning(512)
    fft_vals = np.abs(np.fft.fft(c_sig, n=512))
    freqs_mhz = np.fft.fftfreq(512, d=1.0 / 20.0e6) / 1e6
    pos_mask = freqs_mhz >= 0
    freq_axis = freqs_mhz[pos_mask]
    mag_db = 20 * np.log10(np.maximum(fft_vals[pos_mask], 1e-6))
    mag_db -= np.max(mag_db)  # Normalize peak to 0 dB

    ax.plot(freq_axis, mag_db, color='#1f77b4', linewidth=1.4, label='Spectral Magnitude Spectrum')
    peak_f = freq_axis[np.argmax(mag_db)]
    ax.axvline(x=peak_f, color='#d62728', linestyle=':', linewidth=1.4, label=f'Carrier Peak ({peak_f:.2f} MHz)')
    ax.axhline(y=-3.0, color='#2ca02c', linestyle='--', linewidth=1.2, label='-3 dB Bandwidth Threshold')

    ax.set_title('Complex FFT Spectral Response on FPGA Window (N = 512)')
    ax.set_xlabel('Frequency (MHz)')
    ax.set_ylabel('Normalized Magnitude (dB)')
    ax.set_ylim(-50, 5)
    ax.legend(loc='upper right', frameon=True, edgecolor='#cccccc')
    ax.grid(False)
    save_fig(fig, 'figure_04_fft_spectrum.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 5: Latency Comparison of S-FPGA, P-FPGA, and PP-FPGA
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    means_lat = [df_runs[df_runs['model'] == m]['total_latency_ms'].mean() for m in models]
    stds_lat = [df_runs[df_runs['model'] == m]['total_latency_ms'].std() for m in models]
    
    bars = ax.bar(arch_labels, means_lat, yerr=stds_lat, capsize=5, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, height + 0.005, f"{height:.4f} ms",
                ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('Total Processing Latency Comparison per Window')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('Total Latency per Window (ms)')
    ax.set_ylim(0, max(means_lat) * 1.18)
    ax.grid(False)
    save_fig(fig, 'figure_05_latency_comparison.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 6: Throughput Comparison
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    means_th = [df_runs[df_runs['model'] == m]['throughput_mbps'].mean() for m in models]
    stds_th = [df_runs[df_runs['model'] == m]['throughput_mbps'].std() for m in models]

    bars = ax.bar(arch_labels, means_th, yerr=stds_th, capsize=5, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, height + 80, f"{height:.1f} Mbps",
                ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('Data Processing Throughput Comparison')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('Throughput (Mbps)')
    ax.set_ylim(0, max(means_th) * 1.18)
    ax.grid(False)
    save_fig(fig, 'figure_06_throughput_comparison.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 7: Speedup Comparison
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    speedups = [df_runs[df_runs['model'] == m]['speedup_total'].mean() for m in models]
    comp_speedups = [df_runs[df_runs['model'] == m]['speedup_comp'].mean() for m in models]

    x = np.arange(len(models))
    width = 0.35
    rects1 = ax.bar(x - width/2, speedups, width, label='Overall Latency Speedup', color='#1f77b4', edgecolor='black')
    rects2 = ax.bar(x + width/2, comp_speedups, width, label='Computation Speedup', color='#ff7f0e', edgecolor='black')

    for rect in rects1:
        h = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()/2.0, h + 1.5, f"{h:.1f}x", ha='center', va='bottom', fontsize=8.5, weight='bold')
    for rect in rects2:
        h = rect.get_height()
        ax.text(rect.get_x() + rect.get_width()/2.0, h + 1.5, f"{h:.1f}x", ha='center', va='bottom', fontsize=8.5, weight='bold')

    ax.set_xticks(x)
    ax.set_xticklabels(arch_labels)
    ax.set_title('Speedup Factors Relative to Sequential FPGA (S-FPGA)')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('Speedup Factor (x)')
    ax.set_ylim(0, max(max(speedups), max(comp_speedups)) * 1.15)
    ax.legend(loc='upper left', frameon=True, edgecolor='#cccccc')
    ax.grid(False)
    save_fig(fig, 'figure_07_speedup_comparison.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 8: LUT Utilization
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    lut_pcts = [df_runs[df_runs['model'] == m]['lut_pct'].mean() for m in models]
    bars = ax.bar(arch_labels, lut_pcts, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, h + 0.8, f"{h:.2f}%", ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('FPGA Look-Up Table (LUT) Utilization')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('LUT Utilization (% of Device Capacity)')
    ax.set_ylim(0, max(lut_pcts) * 1.25)
    ax.grid(False)
    save_fig(fig, 'figure_08_lut_utilization.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 9: Flip-Flop Utilization
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    ff_pcts = [df_runs[df_runs['model'] == m]['ff_pct'].mean() for m in models]
    bars = ax.bar(arch_labels, ff_pcts, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, h + 0.6, f"{h:.2f}%", ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('FPGA Flip-Flop (FF) Utilization')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('Flip-Flop Utilization (% of Device Capacity)')
    ax.set_ylim(0, max(ff_pcts) * 1.25)
    ax.grid(False)
    save_fig(fig, 'figure_09_flipflop_utilization.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 10: BRAM Utilization
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    bram_pcts = [df_runs[df_runs['model'] == m]['bram_pct'].mean() for m in models]
    bars = ax.bar(arch_labels, bram_pcts, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, h + 0.3, f"{h:.2f}%", ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('FPGA Block RAM (BRAM 36Kb) Utilization')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('BRAM Utilization (% of Device Capacity)')
    ax.set_ylim(0, max(bram_pcts) * 1.3)
    ax.grid(False)
    save_fig(fig, 'figure_10_bram_utilization.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 11: DSP Utilization
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    dsp_pcts = [df_runs[df_runs['model'] == m]['dsp_pct'].mean() for m in models]
    bars = ax.bar(arch_labels, dsp_pcts, color=model_colors, width=0.55, edgecolor='black')
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2.0, h + 0.3, f"{h:.2f}%", ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('FPGA DSP48E2 Slice Utilization')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('DSP Utilization (% of Device Capacity)')
    ax.set_ylim(0, max(dsp_pcts) * 1.3)
    ax.grid(False)
    save_fig(fig, 'figure_11_dsp_utilization.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 12: Power Consumption (Static vs Dynamic vs Total)
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    p_static = [df_runs[df_runs['model'] == m]['p_static_w'].mean() for m in models]
    p_dyn = [df_runs[df_runs['model'] == m]['p_dynamic_w'].mean() for m in models]

    ax.bar(arch_labels, p_static, label='Static Leakage Power', color='#718096', width=0.55, edgecolor='black')
    ax.bar(arch_labels, p_dyn, bottom=p_static, label='Dynamic Logic Power', color='#e53e3e', width=0.55, edgecolor='black')

    totals = [s + d for s, d in zip(p_static, p_dyn)]
    for i, t in enumerate(totals):
        ax.text(i, t + 0.1, f"{t:.2f} W", ha='center', va='bottom', fontsize=9.5, weight='bold')

    ax.set_title('FPGA Power Consumption Breakdown (Static vs Dynamic)')
    ax.set_xlabel('FPGA Architectural Model')
    ax.set_ylabel('Power Consumption (W)')
    ax.set_ylim(0, max(totals) * 1.2)
    ax.legend(loc='upper left', frameon=True, edgecolor='#cccccc')
    ax.grid(False)
    save_fig(fig, 'figure_12_power_consumption.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 13: Overall FPGA Resource Comparison
    # ----------------------------------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8.0, 5.0), dpi=800)
    categories = ['LUT (%)', 'Flip-Flop (%)', 'BRAM (%)', 'DSP (%)']
    x = np.arange(len(categories))
    width = 0.25

    for idx, (m, col) in enumerate(zip(models, model_colors)):
        sub = df_runs[df_runs['model'] == m]
        vals = [sub['lut_pct'].mean(), sub['ff_pct'].mean(), sub['bram_pct'].mean(), sub['dsp_pct'].mean()]
        offset = (idx - 1) * width
        rects = ax.bar(x + offset, vals, width, label=sub['model_name'].iloc[0], color=col, edgecolor='black')
        for r in rects:
            h = r.get_height()
            ax.text(r.get_x() + r.get_width() / 2.0, h + 0.5, f"{h:.1f}%", ha='center', va='bottom', fontsize=7.5)

    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.set_title('Comprehensive FPGA Hardware Resource Utilization Comparison')
    ax.set_xlabel('Hardware Resource Category')
    ax.set_ylabel('Resource Utilization (%)')
    ax.set_ylim(0, 42)
    ax.legend(loc='upper right', frameon=True, edgecolor='#cccccc')
    ax.grid(False)
    save_fig(fig, 'figure_13_resource_comparison.png')

    # ----------------------------------------------------------------------------------------------
    # Figure 14: Overall Performance Summary (Throughput vs Latency Trade-Off)
    # ----------------------------------------------------------------------------------------------
    fig, ax1 = plt.subplots(figsize=(7.5, 4.8), dpi=800)
    ax2 = ax1.twinx()

    x = np.arange(len(models))
    w = 0.35
    th_vals = [df_runs[df_runs['model'] == m]['throughput_mbps'].mean() for m in models]
    lat_vals = [df_runs[df_runs['model'] == m]['total_latency_ms'].mean() for m in models]

    b1 = ax1.bar(x - w/2, th_vals, w, color='#2ca02c', label='Throughput (Mbps)', edgecolor='black')
    b2 = ax2.bar(x + w/2, lat_vals, w, color='#d62728', label='Total Latency (ms)', edgecolor='black')

    ax1.set_xlabel('FPGA Architectural Model')
    ax1.set_ylabel('Throughput (Mbps)', color='#2ca02c')
    ax2.set_ylabel('Total Latency per Window (ms)', color='#d62728')
    ax1.tick_params(axis='y', labelcolor='#2ca02c')
    ax2.tick_params(axis='y', labelcolor='#d62728')

    ax1.set_xticks(x)
    ax1.set_xticklabels(arch_labels)
    ax1.set_title('System Performance Summary: Throughput vs Latency Trade-Off')
    ax1.set_ylim(0, max(th_vals) * 1.2)
    ax2.set_ylim(0, max(lat_vals) * 1.2)
    ax1.grid(False)
    ax2.grid(False)
    save_fig(fig, 'figure_14_performance_summary.png')

# ==================================================================================================
# 9. DOCUMENTATION GENERATION (README.txt)
# ==================================================================================================
def generate_readme(output_dir: Path, sim_results: dict):
    """
    Generates summary/README.txt documenting experimental setup, models, and file inventory.
    """
    summary_dir = output_dir / 'summary'
    readme_path = summary_dir / 'README.txt'

    readme_content = f"""====================================================================================================
RESEARCH PROJECT EXPERIMENTAL EVALUATION REPORT & ARTIFACT DOCUMENTATION
====================================================================================================
Title:
  The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput in Real-Time 
  Embedded Communication Systems

Random Seed: {RANDOM_SEED} (Strictly reproducible across all random generators)
Reference Hardware Architecture: AMD/Xilinx Zynq UltraScale+ XCZU9EG (FFVC900-2-e)
Operating Core Voltage: 0.85 V

----------------------------------------------------------------------------------------------------
1. EXPERIMENTAL WORKFLOW OVERVIEW
----------------------------------------------------------------------------------------------------
This implementation executes the 7-stage research workflow defined in the manuscript:
  Step 1: Communication Signal Dataset Generation
          - Multi-condition synthetic digital communication signals (QPSK modulated I/Q envelope).
          - Sampling Frequency: 20.0 MHz, Carrier Frequency: 2.5 MHz, Symbol Rate: 500 kBaud.
          - Additive White Gaussian Noise (AWGN) across 5 SNR levels (0, 5, 10, 15, 20 dB).
          - Total Generated Samples: {sim_results['total_samples']:,} samples.

  Step 2: Signal Preprocessing
          - Noise filtering using 33-tap linear-phase bandpass FIR filter.
          - DC offset removal and I/Q channel balance.
          - Normalization to [-1.0, 1.0] for FPGA fixed-point Q1.15 arithmetic.

  Step 3: Streaming Data Segmentation
          - Fixed-length windowing (N = 512 samples per window).
          - 40 streaming windows across 5 SNR conditions.
          - Window metrics: Mean Amplitude, RMS, Signal Power.

  Step 4: FPGA Data Transfer Modeling
          - High-throughput AXI4-Stream + DMA transfer modeling between host CPU and FPGA.
          - Bus Width: 64-bit (8 bytes/cycle) at 200 MHz AXI clock.
          - DMA setup latency: 1.50 us + transmission burst duration: 1.28 us = 2.78 us.

  Step 5: Parallel Pipelined FIR-FFT Processing
          - 64-tap Symmetric Lowpass FIR Filter.
          - 512-point Complex Fast Fourier Transform (FFT).
          - Evaluated across three comparable architectural paradigms:
            * Sequential FPGA (S-FPGA): Single MAC core, unpipelined batch execution (150 MHz).
            * Parallel FPGA (P-FPGA): 8-channel parallel MAC + 8 butterfly units (200 MHz).
            * Parallel Pipelined FPGA (PP-FPGA): 8-channel systolic FIR + SDF Radix-2^2 pipelined
              FFT with 4-stage fully overlapped streaming execution (250 MHz).

  Step 6: FPGA-to-Host Data Transfer Modeling
          - Output spectral features transferred back via AXI4-Stream + DMA.

  Step 7: Performance and Resource Evaluation
          - Statistical analysis across 20 independent experimental runs with system DMA jitter.
          - Metrics: Processing Latency, Transfer Latency, Computation Latency, Total Latency,
            Throughput (Mbps), Speedup, LUT%, FF%, BRAM%, DSP%, and Total Power (W).

----------------------------------------------------------------------------------------------------
2. SIMULATION & MODELING ASSUMPTIONS
----------------------------------------------------------------------------------------------------
- S-FPGA:
  * FIR requires N * M = 512 * 64 = 32,768 cycles.
  * Radix-2 FFT requires (N/2)*log2(N)*4 = 2,304 * 4 = 9,216 cycles.
  * Total Computation: 41,984 cycles @ 150 MHz -> ~0.280 ms.
  * Non-overlapped end-to-end latency: T_total = T_H2F + T_comp + T_F2H -> ~0.285 ms.

- P-FPGA:
  * Parallelism Factor P = 8.
  * FIR cycles: 32,768 / 8 + 16 = 4,112 cycles.
  * FFT cycles: 9,216 / 8 + 16 = 1,168 cycles.
  * Total Computation: 5,280 cycles @ 200 MHz -> ~0.0264 ms.
  * Total end-to-end latency: ~0.0314 ms (Speedup: ~9.1x).

- PP-FPGA:
  * 8-channel systolic FIR + Single-path Delay Feedback (SDF) Radix-2^2 pipelined FFT.
  * Fully overlapped 4-stage streaming pipeline (DMA In -> FIR -> FFT -> DMA Out).
  * Pipeline Initiation Interval II = 64 cycles @ 250 MHz -> ~0.256 us.
  * Streaming throughput bound by DMA interval (2.60 us) -> ~6,300 Mbps (Speedup: ~49.1x).

----------------------------------------------------------------------------------------------------
3. COMPLETE ARTIFACT FILE INVENTORY
----------------------------------------------------------------------------------------------------
data/
  - generated_signal_samples.csv   : Sample-level raw I/Q signal dataset with SNR metadata.
  - preprocessed_signal_samples.csv: Conditioned, filtered, and normalized sample dataset.
  - signal_windows.csv             : Window-level segmented metrics (mean amp, RMS, power).
  - spectral_features.csv          : FFT spectral features (peak mag, dominant freq, bandwidth).

tables/
  - table_01_dataset_summary.csv          : Comprehensive communication dataset parameters.
  - table_02_signal_parameters.csv        : Signal processing & windowing configurations.
  - table_03_model_performance.csv        : Performance metrics across models (mean, std, min, max).
  - table_04_latency_analysis.csv         : Detailed stage latency breakdown (DMA vs FIR vs FFT).
  - table_05_throughput_analysis.csv      : Throughput scaling across window sizes.
  - table_06_fpga_resource_utilization.csv: LUT, FF, BRAM, and DSP utilization against XCZU9EG limits.
  - table_07_power_analysis.csv           : Static, Dynamic, Total Power, and energy efficiency.
  - table_08_speedup_analysis.csv         : Speedup factors relative to S-FPGA.
  - table_09_overall_comparison.csv       : Master IEEE-ready multi-column comparison table.

plots/
  - figure_01_raw_signal.png              : Raw communication waveform in time domain.
  - figure_02_preprocessed_signal.png     : Raw vs preprocessed signal comparison.
  - figure_03_signal_windowing.png        : Fixed-length streaming window segmentation.
  - figure_04_fft_spectrum.png            : Complex FFT magnitude spectrum.
  - figure_05_latency_comparison.png      : Total window processing latency comparison.
  - figure_06_throughput_comparison.png   : Data throughput comparison (Mbps).
  - figure_07_speedup_comparison.png      : Overall and computation speedup factors.
  - figure_08_lut_utilization.png         : Look-Up Table utilization (%).
  - figure_09_flipflop_utilization.png    : Flip-Flop utilization (%).
  - figure_10_bram_utilization.png        : Block RAM utilization (%).
  - figure_11_dsp_utilization.png         : DSP48E2 slice utilization (%).
  - figure_12_power_consumption.png       : Static and dynamic power consumption breakdown.
  - figure_13_resource_comparison.png     : Multi-metric hardware resource comparison.
  - figure_14_performance_summary.png     : Throughput vs Latency trade-off summary.

summary/
  - experimental_summary.csv              : Consolidated executive summary across architectures.
  - README.txt                            : This documentation file.
====================================================================================================
"""
    with open(readme_path, 'w', encoding='utf-8') as f:
        f.write(readme_content)

# ==================================================================================================
# 9b. EXCEL REPORT GENERATION
# ==================================================================================================
def generate_excel_report(base_dir: Path):
    """
    Exports all 9 IEEE tables + executive summary + hyperparameter tables into a
    single formatted Excel workbook: IEEE_Results_Report.xlsx
    
    Sheets:
      - Hardware & Software Details
      - Hyperparameter Table
      - Table 01 … Table 09 (IEEE research tables)
      - Executive Summary
    """
    try:
        import openpyxl
        from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side)
        from openpyxl.utils import get_column_letter
    except ImportError:
        print("      [WARNING] openpyxl not installed. Skipping Excel export.")
        print("                Run: pip install openpyxl")
        return

    tables_dir  = base_dir / 'tables'
    summary_dir = base_dir / 'summary'
    out_path    = base_dir / 'IEEE_Results_Report.xlsx'

    wb = openpyxl.Workbook()
    wb.remove(wb.active)  # remove default blank sheet

    # ------------------------------------------------------------------
    # Style helpers
    # ------------------------------------------------------------------
    HDR_FILL   = PatternFill("solid", fgColor="1F3864")   # Dark navy
    HDR_FONT   = Font(name="Times New Roman", bold=True, color="FFFFFF", size=11)
    TITLE_FONT = Font(name="Times New Roman", bold=True, size=13, color="1F3864")
    BODY_FONT  = Font(name="Times New Roman", bold=True, size=10)
    ALT_FILL   = PatternFill("solid", fgColor="DCE6F1")   # Light blue alternating rows
    CENTER     = Alignment(horizontal="center", vertical="center", wrap_text=True)
    LEFT       = Alignment(horizontal="left",   vertical="center", wrap_text=True)
    THIN       = Side(border_style="thin", color="AAAAAA")
    BORDER     = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

    def _write_df_to_sheet(ws, df, title=None, start_row=1):
        """Writes a DataFrame to a worksheet with full bold formatting."""
        row = start_row

        # Optional sheet title
        if title:
            cell = ws.cell(row=row, column=1, value=title)
            cell.font = TITLE_FONT
            cell.alignment = LEFT
            ws.merge_cells(start_row=row, start_column=1,
                           end_row=row, end_column=max(len(df.columns), 1))
            row += 1

        # Header row
        for col_idx, col_name in enumerate(df.columns, start=1):
            cell = ws.cell(row=row, column=col_idx, value=str(col_name))
            cell.font   = HDR_FONT
            cell.fill   = HDR_FILL
            cell.alignment = CENTER
            cell.border = BORDER
        row += 1

        # Data rows
        for r_idx, data_row in enumerate(df.itertuples(index=False), start=0):
            fill = ALT_FILL if r_idx % 2 == 1 else PatternFill("solid", fgColor="FFFFFF")
            for col_idx, value in enumerate(data_row, start=1):
                cell = ws.cell(row=row, column=col_idx, value=value)
                cell.font      = BODY_FONT
                cell.fill      = fill
                cell.alignment = CENTER
                cell.border    = BORDER
            row += 1

        # Freeze pane below header
        ws.freeze_panes = ws.cell(row=(start_row + (2 if title else 1)), column=1)

        # Auto-fit column widths
        for col_idx, col_name in enumerate(df.columns, start=1):
            max_len = max(
                len(str(col_name)),
                *[len(str(v)) for v in df.iloc[:, col_idx - 1].values]
            )
            ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 4, 40)

        return row

    # ------------------------------------------------------------------
    # Sheet 1 – Hardware & Software Details
    # ------------------------------------------------------------------
    ws_hw = wb.create_sheet("Hardware & Software")
    ws_hw.sheet_view.showGridLines = False

    hw_data = pd.DataFrame([
        {"Category": "Hardware", "Parameter": "Target FPGA Device",          "Specification": "AMD/Xilinx Zynq UltraScale+ XCZU9EG"},
        {"Category": "Hardware", "Parameter": "Package / Speed Grade",        "Specification": "FFVC900, -2 Speed Grade"},
        {"Category": "Hardware", "Parameter": "CLB Look-Up Tables (LUTs)",    "Specification": "274,080 Total"},
        {"Category": "Hardware", "Parameter": "CLB Flip-Flops (FFs)",         "Specification": "548,160 Total"},
        {"Category": "Hardware", "Parameter": "Block RAM (BRAM 36Kb)",        "Specification": "912 Blocks (32.8 Mb Total)"},
        {"Category": "Hardware", "Parameter": "DSP48E2 Slices",               "Specification": "2,520 Slices"},
        {"Category": "Hardware", "Parameter": "Nominal Core Voltage",         "Specification": "0.85 V"},
        {"Category": "Hardware", "Parameter": "AXI4-Stream Bus Width",        "Specification": "64-bit (8 Bytes/Cycle)"},
        {"Category": "Hardware", "Parameter": "AXI Clock Frequency",          "Specification": "200 MHz"},
        {"Category": "Hardware", "Parameter": "DMA Interface",                "Specification": "AXI4-Stream DMA (Scatter-Gather)"},
        {"Category": "Hardware", "Parameter": "DMA Setup Overhead",           "Specification": "~1.50 µs"},
        {"Category": "Hardware", "Parameter": "Window Payload per Transfer",  "Specification": "2,048 Bytes (512 Samples × 4 Bytes)"},
        {"Category": "Hardware", "Parameter": "Base DMA Transfer Latency",    "Specification": "2.78 µs (H2F or F2H)"},
        {"Category": "Software", "Parameter": "Programming Language",         "Specification": "Python 3.x"},
        {"Category": "Software", "Parameter": "Scientific Computing",         "Specification": "NumPy, SciPy"},
        {"Category": "Software", "Parameter": "Data Handling",                "Specification": "Pandas"},
        {"Category": "Software", "Parameter": "Visualization (Publication)",  "Specification": "Matplotlib (Agg Backend, 800 DPI PNG)"},
        {"Category": "Software", "Parameter": "Visualization (Dashboard UI)", "Specification": "Plotly, Plotly Express"},
        {"Category": "Software", "Parameter": "Dashboard Framework",          "Specification": "Streamlit"},
        {"Category": "Software", "Parameter": "Excel Export",                 "Specification": "openpyxl"},
        {"Category": "Software", "Parameter": "Random Seed (Reproducibility)","Specification": "42"},
        {"Category": "Software", "Parameter": "Plot Font Family",             "Specification": "Times New Roman (Bold, Serif), 12 pt"},
        {"Category": "Software", "Parameter": "Output Formats",               "Specification": "CSV, PNG (800 DPI), XLSX, TXT"},
    ])
    _write_df_to_sheet(ws_hw, hw_data, title="Hardware & Software Details")

    # ------------------------------------------------------------------
    # Sheet 2 – Hyperparameter Table
    # ------------------------------------------------------------------
    ws_hp = wb.create_sheet("Hyperparameter Table")
    ws_hp.sheet_view.showGridLines = False

    hp_data = pd.DataFrame([
        {"Hyperparameter": "Clock Frequency (MHz)",            "S-FPGA": "150",           "P-FPGA": "200",                       "PP-FPGA": "250"},
        {"Hyperparameter": "Parallelism Factor (P)",           "S-FPGA": "1 (Sequential)","P-FPGA": "8 Parallel Lanes",          "PP-FPGA": "8 Pipelined Lanes"},
        {"Hyperparameter": "FIR Filter Taps",                  "S-FPGA": "64",            "P-FPGA": "64",                        "PP-FPGA": "64"},
        {"Hyperparameter": "FIR Computation Cycles",           "S-FPGA": "32,768",        "P-FPGA": "4,112",                     "PP-FPGA": "128"},
        {"Hyperparameter": "FFT Transform Size (N)",           "S-FPGA": "512-point",     "P-FPGA": "512-point",                 "PP-FPGA": "512-point"},
        {"Hyperparameter": "FFT Algorithm",                    "S-FPGA": "Radix-2 Sequential","P-FPGA": "Radix-2 Multi-Bank Parallel","PP-FPGA": "Radix-2² SDF Streaming"},
        {"Hyperparameter": "FFT Butterfly Engines",            "S-FPGA": "1",             "P-FPGA": "8",                         "PP-FPGA": "Pipelined SDF"},
        {"Hyperparameter": "FFT Computation Cycles",           "S-FPGA": "9,216",         "P-FPGA": "1,168",                     "PP-FPGA": "100"},
        {"Hyperparameter": "Total Computation Cycles",         "S-FPGA": "41,984",        "P-FPGA": "5,280",                     "PP-FPGA": "228"},
        {"Hyperparameter": "Pipeline Stages",                  "S-FPGA": "Non-overlapped (Batch)","P-FPGA": "Block-Sequential",  "PP-FPGA": "4-Stage Fully Overlapped"},
        {"Hyperparameter": "Pipeline Init. Interval (II)",     "S-FPGA": "N/A",           "P-FPGA": "N/A",                       "PP-FPGA": "64 Cycles/Window"},
        {"Hyperparameter": "Samples Processed per Cycle",      "S-FPGA": "1",             "P-FPGA": "8",                         "PP-FPGA": "8"},
        {"Hyperparameter": "Conditioning FIR Taps",            "S-FPGA": "33",            "P-FPGA": "33",                        "PP-FPGA": "33"},
        {"Hyperparameter": "Conditioning FIR Window",          "S-FPGA": "Hamming",       "P-FPGA": "Hamming",                   "PP-FPGA": "Hamming"},
        {"Hyperparameter": "Conditioning Cutoff Band",         "S-FPGA": "1.70–3.30 MHz","P-FPGA": "1.70–3.30 MHz",             "PP-FPGA": "1.70–3.30 MHz"},
        {"Hyperparameter": "Processing FIR Cutoff",           "S-FPGA": "3.50 MHz",      "P-FPGA": "3.50 MHz",                  "PP-FPGA": "3.50 MHz"},
        {"Hyperparameter": "Spectral Window Function",         "S-FPGA": "Hann",          "P-FPGA": "Hann",                      "PP-FPGA": "Hann"},
        {"Hyperparameter": "Fixed-Point Format",               "S-FPGA": "Q1.15",         "P-FPGA": "Q1.15",                     "PP-FPGA": "Q1.15"},
        {"Hyperparameter": "Streaming Window Length",          "S-FPGA": "512 Samples",   "P-FPGA": "512 Samples",               "PP-FPGA": "512 Samples"},
        {"Hyperparameter": "LUTs Used",                        "S-FPGA": "14,250 (5.20%)","P-FPGA": "48,800 (17.73%)",           "PP-FPGA": "92,400 (33.71%)"},
        {"Hyperparameter": "Flip-Flops Used",                  "S-FPGA": "16,400 (2.99%)","P-FPGA": "52,300 (9.54%)",            "PP-FPGA": "138,500 (25.27%)"},
        {"Hyperparameter": "BRAM Blocks Used",                 "S-FPGA": "18 (1.97%)",    "P-FPGA": "46 (5.04%)",                "PP-FPGA": "98 (10.75%)"},
        {"Hyperparameter": "DSP48E2 Slices Used",              "S-FPGA": "6 (0.24%)",     "P-FPGA": "72 (2.86%)",                "PP-FPGA": "256 (10.16%)"},
        {"Hyperparameter": "Static Power (W)",                 "S-FPGA": "1.10",          "P-FPGA": "1.15",                      "PP-FPGA": "1.22"},
        {"Hyperparameter": "Dynamic Power (W)",                "S-FPGA": "0.55",          "P-FPGA": "1.95",                      "PP-FPGA": "3.63"},
        {"Hyperparameter": "Total Power (W)",                  "S-FPGA": "1.65",          "P-FPGA": "3.10",                      "PP-FPGA": "4.85"},
        {"Hyperparameter": "Simulation Runs (n_runs)",         "S-FPGA": "20",            "P-FPGA": "20",                        "PP-FPGA": "20"},
        {"Hyperparameter": "DMA Jitter (sigma)",               "S-FPGA": "±4%",           "P-FPGA": "±4%",                       "PP-FPGA": "±4%"},
        {"Hyperparameter": "Clock Frequency Jitter (sigma)",   "S-FPGA": "±0.5%",         "P-FPGA": "±0.5%",                     "PP-FPGA": "±0.5%"},
        {"Hyperparameter": "Resource Variation (sigma)",       "S-FPGA": "±0.8%",         "P-FPGA": "±0.8%",                     "PP-FPGA": "±0.8%"},
        {"Hyperparameter": "Sampling Frequency (Fs)",          "S-FPGA": "20 MHz",        "P-FPGA": "20 MHz",                    "PP-FPGA": "20 MHz"},
        {"Hyperparameter": "Carrier Frequency (Fc)",           "S-FPGA": "2.5 MHz",       "P-FPGA": "2.5 MHz",                   "PP-FPGA": "2.5 MHz"},
        {"Hyperparameter": "Modulation Scheme",                "S-FPGA": "QPSK",          "P-FPGA": "QPSK",                      "PP-FPGA": "QPSK"},
        {"Hyperparameter": "SNR Range",                        "S-FPGA": "0–20 dB",       "P-FPGA": "0–20 dB",                   "PP-FPGA": "0–20 dB"},
    ])
    _write_df_to_sheet(ws_hp, hp_data, title="Hyperparameter Table — S-FPGA vs P-FPGA vs PP-FPGA")

    # ------------------------------------------------------------------
    # Sheets 3–11 – IEEE Tables 01–09 + Executive Summary
    # ------------------------------------------------------------------
    table_sheets = [
        ("table_01_dataset_summary.csv",           "Table 01 - Dataset Summary",          "Table 01: Communication Signal Dataset Summary"),
        ("table_02_signal_parameters.csv",         "Table 02 - Signal Parameters",        "Table 02: Signal Parameters & Preprocessing Configuration"),
        ("table_03_model_performance.csv",         "Table 03 - Model Performance",        "Table 03: FPGA Model Performance (Mean ± Std across 20 Runs)"),
        ("table_04_latency_analysis.csv",          "Table 04 - Latency Analysis",         "Table 04: Stage-Level Latency Analysis (ms)"),
        ("table_05_throughput_analysis.csv",       "Table 05 - Throughput Analysis",      "Table 05: Throughput Scaling across Window Sizes"),
        ("table_06_fpga_resource_utilization.csv", "Table 06 - Resource Utilization",     "Table 06: FPGA Resource Utilization (XCZU9EG)"),
        ("table_07_power_analysis.csv",            "Table 07 - Power Analysis",           "Table 07: Power Dissipation & Energy Efficiency"),
        ("table_08_speedup_analysis.csv",          "Table 08 - Speedup Analysis",         "Table 08: Speedup Factors Relative to S-FPGA Baseline"),
        ("table_09_overall_comparison.csv",        "Table 09 - Overall Comparison",       "Table 09: Comprehensive IEEE Multi-Architecture Comparison"),
    ]

    for csv_name, sheet_name, title_text in table_sheets:
        csv_path = tables_dir / csv_name
        if csv_path.exists():
            df_t = pd.read_csv(csv_path)
            ws_t = wb.create_sheet(sheet_name)
            ws_t.sheet_view.showGridLines = False
            _write_df_to_sheet(ws_t, df_t, title=title_text)

    # Executive Summary sheet
    summary_csv = summary_dir / 'experimental_summary.csv'
    if summary_csv.exists():
        df_sum = pd.read_csv(summary_csv)
        ws_sum = wb.create_sheet("Executive Summary")
        ws_sum.sheet_view.showGridLines = False
        _write_df_to_sheet(ws_sum, df_sum, title="Executive Summary: FPGA Architecture Experimental Results")

    wb.save(out_path)
    print(f"      [Excel] Workbook saved: {out_path}")

# ==================================================================================================
# 10. MAIN EXECUTION PIPELINE
# ==================================================================================================
def main():
    print("=" * 80)
    print("The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput")
    print("in Real-Time Embedded Communication Systems")
    print("=" * 80)
    print(f"Random Seed: {RANDOM_SEED}")
    print("Executing research workflow...\n")

    # Determine base output path
    base_dir = Path(__file__).resolve().parent / "FPGA_Signal_Processing_Results"
    dirs = setup_directories(base_dir)

    # 1. Generate Synthetic Dataset
    print("[1/7] Generating synthetic multi-condition communication signal dataset...")
    df_raw = generate_communication_signals(n_signals=5, samples_per_signal=4096, fs=20.0e6, fc=2.5e6)
    df_raw.to_csv(dirs['data'] / 'generated_signal_samples.csv', index=False)
    print(f"      Saved: {dirs['data'] / 'generated_signal_samples.csv'} ({len(df_raw)} samples)")

    # 2. Preprocess Signals
    print("[2/7] Executing signal preprocessing (conditioning, filtering, normalization)...")
    df_preprocessed = preprocess_signals(df_raw, fs=20.0e6)
    df_preprocessed.to_csv(dirs['data'] / 'preprocessed_signal_samples.csv', index=False)
    print(f"      Saved: {dirs['data'] / 'preprocessed_signal_samples.csv'}")

    # 3. Stream Segmentation
    print("[3/7] Segmenting streaming data into fixed-length windows (N = 512)...")
    df_windows = segment_streaming_data(df_preprocessed, window_length=512)
    df_windows.to_csv(dirs['data'] / 'signal_windows.csv', index=False)
    print(f"      Saved: {dirs['data'] / 'signal_windows.csv'} ({len(df_windows)} windows)")

    # 4. FIR + FFT Processing
    print("[4/7] Performing 64-tap FIR filtering and 512-point FFT spectral analysis...")
    df_spectral = process_fir_fft(df_preprocessed, window_length=512, fs=20.0e6)
    df_spectral.to_csv(dirs['data'] / 'spectral_features.csv', index=False)
    print(f"      Saved: {dirs['data'] / 'spectral_features.csv'}")

    # 5. FPGA Hardware Simulation
    print("[5/7] Simulating FPGA models (S-FPGA, P-FPGA, PP-FPGA) over 20 experimental runs...")
    sim_results = simulate_fpga_models(df_windows, n_runs=20)

    # 6. Generate Tables & Summary
    print("[6/7] Generating 9 IEEE-ready CSV tables, consolidated summary, and Excel workbook...")
    generate_tables(base_dir, sim_results, df_raw, df_preprocessed, df_windows, df_spectral)
    generate_readme(base_dir, sim_results)
    generate_excel_report(base_dir)
    print(f"      All tables saved to: {dirs['tables']}")
    print(f"      Summary saved to:    {dirs['summary']}")
    print(f"      Excel workbook:       {base_dir / 'IEEE_Results_Report.xlsx'}")

    # 7. Generate Plots
    print("[7/7] Generating 14 publication-grade figures (800 DPI, Times New Roman)...")
    generate_plots(base_dir, sim_results, df_raw, df_preprocessed, df_windows, df_spectral)
    print(f"      All plots saved to:  {dirs['plots']}")

    # Final Statistics Reporting
    runs_data = sim_results['runs_data']
    s_lat = np.mean([r['total_latency_ms'] for r in runs_data['S-FPGA']])
    s_th = np.mean([r['throughput_mbps'] for r in runs_data['S-FPGA']])
    p_lat = np.mean([r['total_latency_ms'] for r in runs_data['P-FPGA']])
    p_th = np.mean([r['throughput_mbps'] for r in runs_data['P-FPGA']])
    p_sp = np.mean([r['speedup_total'] for r in runs_data['P-FPGA']])
    pp_lat = np.mean([r['total_latency_ms'] for r in runs_data['PP-FPGA']])
    pp_th = np.mean([r['throughput_mbps'] for r in runs_data['PP-FPGA']])
    pp_sp = np.mean([r['speedup_total'] for r in runs_data['PP-FPGA']])

    print("\n" + "=" * 80)
    print("EXPERIMENTAL EVALUATION SUMMARY")
    print("=" * 80)
    print(f"Number of generated samples: {len(df_raw)}")
    print(f"Number of signal windows:    {len(df_windows)}")
    print(f"Number of FFT windows:       {len(df_spectral)}")
    print(f"Number of experimental runs: 20")
    print("-" * 80)
    print(f"S-FPGA results:  Latency = {s_lat:.4f} ms | Throughput = {s_th:.2f} Mbps | Speedup = 1.00x")
    print(f"P-FPGA results:  Latency = {p_lat:.4f} ms | Throughput = {p_th:.2f} Mbps | Speedup = {p_sp:.2f}x")
    print(f"PP-FPGA results: Latency = {pp_lat:.4f} ms | Throughput = {pp_th:.2f} Mbps | Speedup = {pp_sp:.2f}x")
    print("-" * 80)
    print(f"Output directory: {base_dir}")
    print("Experiment completed successfully.")
    print("=" * 80)

if __name__ == "__main__":
    main()
