﻿import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

# ── Output ─────────────────────────────────────────────────────────────────
OUT = Path(r"D:\Alan christo\October 2026\2026-09-KIT-COC-ST-280\FPGA_Signal_Processing_Results\plots\figure_00_architecture_diagram.png")
OUT.parent.mkdir(parents=True, exist_ok=True)

# ── Colours ─────────────────────────────────────────────────────────────────
BG   = "#0d1b2a"
CHIP = "#0f2035"
HOST = "#0e1f30"
W    = "#e8f0fe"
GR   = "#7b93b0"
BLU  = "#4a9eff"   # S-FPGA
ORG  = "#ff8c2a"   # P-FPGA
GRN  = "#2ed573"   # PP-FPGA
GLD  = "#ffd700"   # AXI/DMA
CYN  = "#00d4ff"   # arrows

plt.rcParams.update({
    'font.family':  'serif',
    'font.serif':   ['Times New Roman','DejaVu Serif'],
    'font.weight':  'bold',
    'text.color':   W,
    'figure.facecolor': BG,
    'axes.facecolor':   BG,
    'savefig.facecolor':BG,
    'axes.grid': False,
})

# ── Canvas ───────────────────────────────────────────────────────────────────
FW, FH = 28, 18
fig, ax = plt.subplots(figsize=(FW, FH), dpi=150)
ax.set_xlim(0, FW); ax.set_ylim(0, FH)
ax.axis('off')

# ── Helpers ──────────────────────────────────────────────────────────────────
def rbox(x, y, w, h, ec, fc=CHIP, lw=2.2, r=0.3):
    ax.add_patch(FancyBboxPatch((x,y), w, h,
        boxstyle=f"round,pad={r}", lw=lw, edgecolor=ec, facecolor=fc, zorder=3))

def txt(x, y, s, fs=10, color=W, ha='center', va='center', style='normal'):
    ax.text(x, y, s, fontsize=fs, fontweight='bold', color=color,
            ha=ha, va=va, fontstyle=style, zorder=5,
            wrap=False)

def arrow(x0,y0,x1,y1,color=CYN,lw=2.5):
    ax.annotate("", xy=(x1,y1), xytext=(x0,y0),
        arrowprops=dict(arrowstyle="-|>", color=color, lw=lw,
                        connectionstyle="arc3,rad=0"), zorder=6)

# ═══════════════════════════════════════════════════════════════════════════
# 1. TITLE  (top strip)
# ═══════════════════════════════════════════════════════════════════════════
rbox(0.3, 16.8, 27.4, 1.0, ec=GLD, fc="#0a1520", lw=1.5, r=0.2)
txt(14, 17.35,
    "FPGA-Based Parallel Signal Processing — System Architecture Diagram",
    fs=17, color=W)
txt(14, 16.95,
    "The Impact of FPGA-Based Parallel Signal Processing on Latency and Throughput in Real-Time Embedded Communication Systems",
    fs=9, color=GR, style='italic')

# ═══════════════════════════════════════════════════════════════════════════
# 2. HOST SYSTEM — LEFT  (x=0.3 … 4.5)
# ═══════════════════════════════════════════════════════════════════════════
HLx, HLy, HLw, HLh = 0.3, 3.2, 4.2, 12.8
rbox(HLx, HLy, HLw, HLh, ec=BLU, fc=HOST, lw=2.5)
txt(HLx+HLw/2, HLy+HLh+0.35, "HOST SYSTEM  (Transmit)", fs=13, color=BLU)

host_L_blocks = [
    ("Signal Source / ADC",        "QPSK • Fs = 20 MHz • Fc = 2.5 MHz",  GR),
    ("Preprocessing Unit",         "Bandpass FIR Filter • 33 Taps",       GR),
    ("Stream Segmentation",        "Fixed Window • N = 512 Samples",      GR),
    ("DMA Controller",             "Scatter-Gather • IRQ Driven",         GLD),
    ("AXI4-Stream Master IF",      "64-bit Data Bus • 200 MHz",           GLD),
]
by = HLy + HLh - 0.4
bh = 2.1
for (title, sub, ec) in host_L_blocks:
    by -= bh
    rbox(HLx+0.25, by, HLw-0.5, bh-0.15, ec=ec, fc="#102030", lw=1.6, r=0.2)
    txt(HLx+HLw/2, by+(bh-0.15)*0.62, title, fs=10.5, color=W)
    txt(HLx+HLw/2, by+(bh-0.15)*0.28, sub,   fs=8.5,  color=ec)
    by -= 0.2

# ═══════════════════════════════════════════════════════════════════════════
# 3. FPGA CHIP BOUNDARY  (x=5.2 … 22.0)
# ═══════════════════════════════════════════════════════════════════════════
FPx, FPy, FPw, FPh = 5.2, 1.2, 16.8, 15.2
rbox(FPx, FPy, FPw, FPh, ec=GLD, fc=CHIP, lw=3.5, r=0.4)
txt(FPx+FPw/2, FPy+FPh+0.55,
    "AMD / Xilinx Zynq UltraScale+   XCZU9EG   (FFVC900  -2 Speed Grade)",
    fs=14, color=GLD)
txt(FPx+FPw/2, FPy+FPh+0.18,
    "274,080 LUTs    548,160 Flip-Flops    912 BRAMs (36Kb)    2,520 DSP48E2 Slices    Core Voltage: 0.85 V",
    fs=10, color=GR)

# AXI DMA top bar
rbox(FPx+0.3, FPy+FPh-2.0, FPw-0.6, 1.6, ec=GLD, fc="#0e200e", lw=2, r=0.2)
txt(FPx+FPw/2, FPy+FPh-1.2,
    "AXI4-Stream H2F DMA Input Subsystem", fs=11.5, color=GLD)
txt(FPx+FPw/2, FPy+FPh-1.65,
    "64-bit Data Width  @  200 MHz   |   Window Payload: 2,048 Bytes   |   DMA Setup: 1.50 µs   |   Burst Transfer: 1.28 µs   |   Total H2F: 2.78 µs",
    fs=8.5, color=GR)

# AXI DMA bottom bar
rbox(FPx+0.3, FPy+0.4, FPw-0.6, 1.6, ec=GLD, fc="#0e200e", lw=2, r=0.2)
txt(FPx+FPw/2, FPy+1.2,
    "AXI4-Stream F2H DMA Output Subsystem", fs=11.5, color=GLD)
txt(FPx+FPw/2, FPy+0.75,
    "64-bit Data Width  @  200 MHz   |   Scatter-Gather Descriptor Management   |   Total F2H Latency: 2.78 µs",
    fs=8.5, color=GR)

# ── Column definitions ────────────────────────────────────────────────────
COL_Y_TOP = FPy + FPh - 2.05   # just below H2F bar
COL_Y_BOT = FPy + 2.05         # just above F2H bar
COL_H = COL_Y_TOP - COL_Y_BOT  # ≈ 10.9

col_w   = 4.6
col_gap = 0.45
c1x = FPx + 0.55          # S-FPGA left edge
c2x = c1x + col_w + col_gap
c3x = c2x + col_w + col_gap

def draw_column(cx, arch_label, arch_color, clk,
                fir_name, fir_detail, fir_cycles,
                fft_name, fft_detail, fft_cycles,
                stats_text):
    """Draw one complete architecture column."""
    BRAM_H = 1.0
    FIR_H  = 2.5
    FFT_H  = 2.5
    V_GAP  = 0.4
    ARROW  = 0.25

    # Column border
    rbox(cx, COL_Y_BOT, col_w, COL_H, ec=arch_color, fc=CHIP, lw=2.8, r=0.3)

    # Arch name header
    rbox(cx+0.15, COL_Y_TOP-0.9, col_w-0.3, 0.8, ec=arch_color, fc=arch_color+"33", lw=1.5, r=0.15)
    txt(cx+col_w/2, COL_Y_TOP-0.5, arch_label, fs=11, color=arch_color)

    # compute block positions (from top down)
    bram_in_y  = COL_Y_TOP - 0.95 - V_GAP - BRAM_H
    fir_y      = bram_in_y - ARROW - FIR_H
    fft_y      = fir_y     - ARROW - FFT_H
    bram_out_y = fft_y     - ARROW - BRAM_H

    # -- BRAM IN
    rbox(cx+0.2, bram_in_y, col_w-0.4, BRAM_H, ec=GLD, fc="#111e10", lw=1.8, r=0.2)
    txt(cx+col_w/2, bram_in_y+BRAM_H*0.65, "Input Buffer", fs=10, color=GLD)
    txt(cx+col_w/2, bram_in_y+BRAM_H*0.28, "BRAM  (36Kb Block RAM)", fs=8.5, color=GR)

    # arrow in→fir
    arrow(cx+col_w/2, bram_in_y, cx+col_w/2, bram_in_y-ARROW, color=arch_color)

    # -- FIR block
    rbox(cx+0.2, fir_y, col_w-0.4, FIR_H, ec=arch_color, fc="#0d1e30", lw=2, r=0.2)
    txt(cx+col_w/2, fir_y+FIR_H*0.80, fir_name,   fs=10.5, color=W)
    txt(cx+col_w/2, fir_y+FIR_H*0.58, fir_detail,  fs=9.0, color=arch_color)
    txt(cx+col_w/2, fir_y+FIR_H*0.32, fir_cycles,  fs=8.5, color=GR, style='italic')

    # divider line inside FIR box
    ax.plot([cx+0.5, cx+col_w-0.5], [fir_y+FIR_H*0.46, fir_y+FIR_H*0.46],
            color=arch_color+"55", lw=1, zorder=4)

    # arrow fir→fft
    arrow(cx+col_w/2, fir_y, cx+col_w/2, fir_y-ARROW, color=arch_color)

    # -- FFT block
    rbox(cx+0.2, fft_y, col_w-0.4, FFT_H, ec=arch_color, fc="#0d1e30", lw=2, r=0.2)
    txt(cx+col_w/2, fft_y+FFT_H*0.80, fft_name,   fs=10.5, color=W)
    txt(cx+col_w/2, fft_y+FFT_H*0.58, fft_detail,  fs=9.0, color=arch_color)
    txt(cx+col_w/2, fft_y+FFT_H*0.32, fft_cycles,  fs=8.5, color=GR, style='italic')

    ax.plot([cx+0.5, cx+col_w-0.5], [fft_y+FFT_H*0.46, fft_y+FFT_H*0.46],
            color=arch_color+"55", lw=1, zorder=4)

    # arrow fft→bram_out
    arrow(cx+col_w/2, fft_y, cx+col_w/2, fft_y-ARROW, color=arch_color)

    # -- BRAM OUT
    rbox(cx+0.2, bram_out_y, col_w-0.4, BRAM_H, ec=GLD, fc="#111e10", lw=1.8, r=0.2)
    txt(cx+col_w/2, bram_out_y+BRAM_H*0.65, "Output Buffer", fs=10, color=GLD)
    txt(cx+col_w/2, bram_out_y+BRAM_H*0.28, "BRAM  (36Kb Block RAM)", fs=8.5, color=GR)

    # -- Clock label
    txt(cx+col_w/2, COL_Y_BOT+0.65, f"Clock: {clk}", fs=9, color=arch_color)

    # -- Stats badge (below column border, inside chip)
    stats_y = COL_Y_BOT - 0.85
    rbox(cx, stats_y, col_w, 0.7, ec=arch_color, fc="#0a1520", lw=1.5, r=0.1)
    txt(cx+col_w/2, stats_y+0.35, stats_text, fs=8.0, color=arch_color)

    return cx+col_w/2, bram_in_y+BRAM_H/2, bram_out_y+BRAM_H/2


# Draw the 3 columns
_, s_in,  s_out  = draw_column(
    c1x, "S-FPGA  (Sequential)", BLU, "150 MHz",
    "64-tap FIR Filter",
    "Single-MAC  •  Time-Multiplexed",
    "32,768 Cycles  @  150 MHz   →   0.218 ms",
    "512-pt Radix-2 FFT",
    "1 Butterfly Engine  •  4 Cycles / Butterfly",
    "9,216 Cycles  @  150 MHz   →   0.061 ms",
    "6 DSPs  |  14,250 LUTs  |  18 BRAMs  |  1.65 W  |  57 Mbps  |  Speedup: 1.0×")

_, p_in,  p_out  = draw_column(
    c2x, "P-FPGA  (Parallel  P = 8)", ORG, "200 MHz",
    "8-Way Parallel MAC Array",
    "Spatial FIR  •  8 Parallel Channels",
    "4,112 Cycles  @  200 MHz   →   0.021 ms",
    "8 Parallel Butterfly Engines",
    "Radix-2  Multi-Bank  •  8 BF Units",
    "1,168 Cycles  @  200 MHz   →   0.006 ms",
    "72 DSPs  |  48,800 LUTs  |  46 BRAMs  |  3.10 W  |  515 Mbps  |  Speedup: 8.97×")

_, pp_in, pp_out = draw_column(
    c3x, "PP-FPGA  (Parallel Pipelined  P = 8)", GRN, "250 MHz",
    "Systolic FIR Pipeline",
    "64-Stage Deep Register Chain  •  8 Samples/Cycle",
    "128 Cycles  @  250 MHz   →   0.000512 ms",
    "SDF Radix-2² FFT Pipeline",
    "Single-Path Delay Feedback  •  Streaming",
    "100 Cycles  @  250 MHz   →   0.0004 ms",
    "256 DSPs  |  92,400 LUTs  |  98 BRAMs  |  4.85 W  |  6,033 Mbps  |  Speedup: 101.73×")

# ═══════════════════════════════════════════════════════════════════════════
# 4. HOST SYSTEM — RIGHT  (x=22.5 … 27.5)
# ═══════════════════════════════════════════════════════════════════════════
HRx, HRy, HRw, HRh = 22.5, 4.5, 4.9, 10.8
rbox(HRx, HRy, HRw, HRh, ec=GRN, fc=HOST, lw=2.5)
txt(HRx+HRw/2, HRy+HRh+0.35, "HOST SYSTEM  (Receive)", fs=13, color=GRN)

host_R_blocks = [
    ("AXI4-Stream Slave IF", "64-bit Bus  •  200 MHz",         GLD),
    ("DMA Controller",       "F2H  •  Write Channel",          GLD),
    ("Result Buffer",        "512 Complex Samples",            GR),
    ("Spectral Analyser",    "Peak Freq  •  BW  •  Power",     GR),
]
by2 = HRy + HRh - 0.4
bh2 = 2.1
for (title, sub, ec) in host_R_blocks:
    by2 -= bh2
    rbox(HRx+0.25, by2, HRw-0.5, bh2-0.15, ec=ec, fc="#102030", lw=1.6, r=0.2)
    txt(HRx+HRw/2, by2+(bh2-0.15)*0.62, title, fs=10.5, color=W)
    txt(HRx+HRw/2, by2+(bh2-0.15)*0.28, sub,   fs=8.5,  color=ec)
    by2 -= 0.2

# ═══════════════════════════════════════════════════════════════════════════
# 5. INTER-SYSTEM ARROWS  (Host ↔ FPGA)
# ═══════════════════════════════════════════════════════════════════════════
# Left host → FPGA H2F bar
H2F_y = FPy + FPh - 1.2
F2H_y = FPy + 1.2

arrow(HLx+HLw, HLy+HLh*0.6, FPx, H2F_y, color=CYN, lw=3)
ax.text((HLx+HLw+FPx)/2, H2F_y+0.55,
        "H2F Transfer\nAXI4-Stream  64-bit  @  200 MHz\nLatency: 2.78 µs  per Window",
        ha='center', va='center', fontsize=9, fontweight='bold', color=CYN, zorder=6,
        bbox=dict(fc=BG, ec='none', pad=2))

# FPGA F2H → Right host
arrow(FPx+FPw, F2H_y, HRx, HRy+HRh*0.45, color=CYN, lw=3)
ax.text((FPx+FPw+HRx)/2, F2H_y+0.55,
        "F2H Transfer\nAXI4-Stream  64-bit  @  200 MHz\nLatency: 2.78 µs  per Window",
        ha='center', va='center', fontsize=9, fontweight='bold', color=CYN, zorder=6,
        bbox=dict(fc=BG, ec='none', pad=2))

# ═══════════════════════════════════════════════════════════════════════════
# 6. PIPELINE TIMING STRIP  (very bottom)
# ═══════════════════════════════════════════════════════════════════════════
PX, PY, PW, PH = 0.3, 0.05, 27.4, 1.05
rbox(PX, PY, PW, PH, ec="#2c3e50", fc="#060e18", lw=1.5, r=0.15)
txt(PX+PW/2, PY+PH+0.22, "Processing Pipeline — End-to-End Stage Timing",
    fs=11, color=W)

stages = [
    ("H2F DMA  Transfer\n2.78 µs",            0.00, 0.14, GLD),
    ("FIR Filtering\n(S-FPGA: 0.218 ms  |  P-FPGA: 0.021 ms  |  PP-FPGA: 0.000512 ms)",
                                               0.14, 0.55, BLU),
    ("FFT Processing\n(S-FPGA: 0.061 ms  |  P-FPGA: 0.006 ms  |  PP-FPGA: 0.0004 ms)",
                                               0.55, 0.86, ORG),
    ("F2H DMA  Transfer\n2.78 µs",             0.86, 1.00, GRN),
]
SH = 0.70
SY = PY + (PH - SH) / 2
for (slabel, s0, s1, sc) in stages:
    sx = PX + 0.05 + s0 * (PW - 0.1)
    sw = (s1 - s0) * (PW - 0.1) - 0.06
    rbox(sx, SY, sw, SH, ec=sc, fc=sc+"25", lw=1.8, r=0.12)
    txt(sx+sw/2, SY+SH/2, slabel, fs=8.5, color=sc)

# ═══════════════════════════════════════════════════════════════════════════
# 7. LEGEND  (below FPGA chip, right side)
# ═══════════════════════════════════════════════════════════════════════════
LX, LY = 5.5, 0.18
leg_items = [
    (BLU, "S-FPGA   Sequential      150 MHz  |  57 Mbps   |  Speedup 1.00×"),
    (ORG, "P-FPGA   Parallel         200 MHz  |  515 Mbps  |  Speedup 8.97×"),
    (GRN, "PP-FPGA  Pipelined       250 MHz  |  6,033 Mbps|  Speedup 101.73×"),
    (GLD, "AXI4-Stream DMA      64-bit @ 200 MHz  |  2.78 µs per transfer"),
    (CYN, "Data Flow Arrows"),
]
for i, (lc, lt) in enumerate(leg_items):
    lx = LX + i * 4.6
    ax.add_patch(mpatches.Rectangle((lx, LY+0.05), 0.4, 0.45,
                                     fc=lc, ec='none', zorder=5))
    txt(lx+0.55, LY+0.28, lt, fs=7.8, color=W, ha='left')

# ═══════════════════════════════════════════════════════════════════════════
# Save
# ═══════════════════════════════════════════════════════════════════════════
plt.tight_layout(pad=0)
fig.savefig(OUT, dpi=800, bbox_inches='tight', facecolor=BG)
plt.close(fig)
print(f"[OK] Saved: {OUT}")
